<?php
/**
 * WooCodes Email Template - Digital Product Codes
 *
 * This template can be overridden by copying it to yourtheme/woocodes/emails/codes-email.php
 *
 * @package WooCodes\Templates\Emails
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

// Default values
$logo_url = $logo_url ?? woocodes_get_invoice_logo();
$email_title = $email_title ?? woocodes_get_email_title();
$codes_description = $codes_description ?? woocodes_get_codes_description();
$back_to_store_text = $back_to_store_text ?? woocodes_get_back_to_store_text();
$footer_link = $footer_link ?? woocodes_get_invoice_footer_link();
$support_message = $support_message ?? woocodes_get_support_message();
$support_link_text = $support_link_text ?? woocodes_get_support_link_text();
$support_link = $support_link ?? woocodes_get_support_link();
$selected_color = $selected_color ?? woocodes_get_selected_color();
$text_color = $text_color ?? woocodes_get_contrast_color($selected_color);
$codes_data = $codes_data ?? array();
$order = $order ?? null;
$customer_name = $customer_name ?? '';

// Calculate contrast colors
$light_color = woocodes_adjust_color_brightness($selected_color, 40);
$darker_color = woocodes_adjust_color_brightness($selected_color, -20);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo esc_html($email_title); ?></title>
    
    <!--[if mso]>
    <noscript>
        <xml>
            <o:OfficeDocumentSettings>
                <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
        </xml>
    </noscript>
    <![endif]-->
    
    <style type="text/css">
        /* Reset styles */
        body, table, td, p, a, li, blockquote {
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }
        
        table, td {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }
        
        img {
            -ms-interpolation-mode: bicubic;
            border: 0;
            outline: none;
            text-decoration: none;
        }
        
        /* Base styles */
        body {
            margin: 0 !important;
            padding: 0 !important;
            background-color: #f8fafc;
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #333333;
        }
        
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .email-header {
            background: linear-gradient(135deg, <?php echo esc_attr($selected_color); ?>, <?php echo esc_attr($light_color); ?>);
            padding: 40px 30px;
            text-align: center;
            color: <?php echo esc_attr($text_color); ?>;
        }
        
        .email-logo {
            margin-bottom: 20px;
        }
        
        .email-logo img {
            max-width: 200px;
            height: auto;
            display: block;
            margin: 0 auto;
        }
        
        .email-title {
            font-size: 28px;
            font-weight: 800;
            margin: 0 0 10px 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .email-subtitle {
            font-size: 16px;
            margin: 0;
            opacity: 0.9;
        }
        
        .email-body {
            padding: 40px 30px;
        }
        
        .greeting {
            font-size: 18px;
            color: #4b5563;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .codes-description {
            font-size: 18px;
            color: #4b5563;
            margin-bottom: 30px;
            text-align: center;
            line-height: 1.6;
        }
        
        .order-info {
            background-color: #f8fafc;
            border-left: 4px solid <?php echo esc_attr($selected_color); ?>;
            padding: 15px 20px;
            margin-bottom: 30px;
            border-radius: 0 6px 6px 0;
        }
        
        .order-info h3 {
            margin: 0 0 10px 0;
            color: <?php echo esc_attr($selected_color); ?>;
            font-size: 16px;
        }
        
        .order-info p {
            margin: 5px 0;
            color: #6b7280;
            font-size: 14px;
        }
        
        .codes-container {
            background-color: #f8fafc;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid #e5e7eb;
        }
        
        .product-section {
            margin-bottom: 30px;
            padding-bottom: 25px;
            border-bottom: 1px dashed #d1d5db;
        }
        
        .product-section:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        
        .product-title {
            font-size: 20px;
            font-weight: 700;
            color: <?php echo esc_attr($selected_color); ?>;
            margin: 0 0 20px 0;
            text-align: center;
        }
        
        .codes-grid {
            display: block;
        }
        
        .code-item {
            background-color: #ffffff;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 12px;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .code-item:hover {
            border-color: <?php echo esc_attr($selected_color); ?>;
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.15);
        }
        
        .code-text {
            font-family: 'Courier New', Courier, monospace;
            font-size: 18px;
            font-weight: 700;
            color: #111827;
            letter-spacing: 2px;
            margin: 0;
            word-break: break-all;
        }
        
        .code-label {
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }
        
        .footer-section {
            text-align: center;
            padding: 30px;
            background-color: #f8fafc;
            border-top: 1px solid #e5e7eb;
        }
        
        .back-button {
            display: inline-block;
            background: linear-gradient(135deg, <?php echo esc_attr($selected_color); ?>, <?php echo esc_attr($darker_color); ?>);
            color: <?php echo esc_attr($text_color); ?> !important;
            text-decoration: none;
            padding: 16px 32px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 16px;
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }
        
        .back-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(79, 70, 229, 0.4);
        }
        
        .support-info {
            font-size: 14px;
            color: #6b7280;
            line-height: 1.6;
            margin-top: 20px;
        }
        
        .support-link {
            color: <?php echo esc_attr($selected_color); ?>;
            text-decoration: underline;
            font-weight: 600;
        }
        
        .footer-note {
            font-size: 12px;
            color: #9ca3af;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
        
        /* Responsive styles */
        @media only screen and (max-width: 600px) {
            .email-container {
                margin: 0 !important;
                border-radius: 0 !important;
            }
            
            .email-header,
            .email-body,
            .footer-section {
                padding: 25px 20px !important;
            }
            
            .email-title {
                font-size: 24px !important;
            }
            
            .codes-container {
                padding: 20px !important;
            }
            
            .code-item {
                padding: 12px 15px !important;
            }
            
            .code-text {
                font-size: 16px !important;
                letter-spacing: 1px !important;
            }
            
            .back-button {
                padding: 14px 24px !important;
                font-size: 14px !important;
            }
        }
        
        /* Dark mode support */
        @media (prefers-color-scheme: dark) {
            body {
                background-color: #1f2937 !important;
            }
            
            .email-container {
                background-color: #111827 !important;
            }
            
            .codes-container {
                background-color: #1f2937 !important;
                border-color: #374151 !important;
            }
            
            .code-item {
                background-color: #1f2937 !important;
                border-color: #374151 !important;
            }
            
            .code-text {
                color: #f9fafb !important;
            }
            
            .order-info {
                background-color: #1f2937 !important;
            }
            
            .footer-section {
                background-color: #1f2937 !important;
                border-color: #374151 !important;
            }
        }
        
        /* High contrast mode */
        @media (prefers-contrast: high) {
            .code-item {
                border-width: 3px !important;
            }
            
            .back-button {
                border: 2px solid <?php echo esc_attr($text_color); ?> !important;
            }
        }
        
        /* Print styles */
        @media print {
            .email-container {
                box-shadow: none !important;
                border: 2px solid #000 !important;
            }
            
            .back-button {
                display: none !important;
            }
            
            .support-info {
                display: none !important;
            }
        }
    </style>
</head>

<body>
    <div class="email-container">
        <!-- Header Section -->
        <div class="email-header">
            <?php if (!empty($logo_url)): ?>
                <div class="email-logo">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" />
                </div>
            <?php endif; ?>
            
            <h1 class="email-title">
                <?php echo esc_html($email_title); ?>
            </h1>
            
            <?php if (!empty($customer_name)): ?>
                <p class="email-subtitle">
                    <?php 
                    printf(
                        /* translators: %s: customer name */
                        esc_html__('Hello %s!', 'woocodes'),
                        esc_html($customer_name)
                    );
                    ?>
                </p>
            <?php endif; ?>
        </div>

        <!-- Body Section -->
        <div class="email-body">
            <?php if ($order): ?>
                <div class="order-info">
                    <h3><?php esc_html_e('Order Details', 'woocodes'); ?></h3>
                    <p>
                        <strong><?php esc_html_e('Order Number:', 'woocodes'); ?></strong> 
                        #<?php echo esc_html($order->get_order_number()); ?>
                    </p>
                    <p>
                        <strong><?php esc_html_e('Order Date:', 'woocodes'); ?></strong> 
                        <?php echo esc_html($order->get_date_created()->date_i18n(get_option('date_format'))); ?>
                    </p>
                    <p>
                        <strong><?php esc_html_e('Total:', 'woocodes'); ?></strong> 
                        <?php echo wp_kses_post($order->get_formatted_order_total()); ?>
                    </p>
                </div>
            <?php endif; ?>

            <p class="codes-description">
                <?php echo esc_html($codes_description); ?>
            </p>

            <?php if (!empty($codes_data)): ?>
                <div class="codes-container">
                    <?php foreach ($codes_data as $entry): ?>
                        <?php if (!isset($entry['product']) || !isset($entry['codes']) || empty($entry['codes'])) continue; ?>
                        
                        <div class="product-section">
                            <h2 class="product-title">
                                <?php echo esc_html($entry['product']); ?>
                            </h2>
                            
                            <div class="codes-grid">
                                <?php foreach ($entry['codes'] as $index => $code): ?>
                                    <div class="code-item">
                                        <div class="code-label">
                                            <?php 
                                            printf(
                                                /* translators: %d: code number */
                                                esc_html__('Code %d', 'woocodes'),
                                                $index + 1
                                            ); 
                                            ?>
                                        </div>
                                        <p class="code-text">
                                            <?php echo esc_html($code); ?>
                                        </p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Usage Instructions -->
                <div style="background-color: #eff6ff; border-left: 4px solid #3b82f6; padding: 15px 20px; margin-bottom: 30px; border-radius: 0 6px 6px 0;">
                    <h3 style="margin: 0 0 10px 0; color: #1e40af; font-size: 16px;">
                        📖 <?php esc_html_e('How to Use Your Codes', 'woocodes'); ?>
                    </h3>
                    <ul style="margin: 0; padding-left: 20px; color: #1e40af;">
                        <li><?php esc_html_e('Copy each code exactly as shown (including any dashes or special characters)', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Use the codes on the platform or website where you purchased the product', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Keep this email safe for future reference', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Contact support if you have any issues redeeming your codes', 'woocodes'); ?></li>
                    </ul>
                </div>

                <!-- Security Notice -->
                <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px 20px; margin-bottom: 30px; border-radius: 0 6px 6px 0;">
                    <h3 style="margin: 0 0 10px 0; color: #92400e; font-size: 16px;">
                        🔒 <?php esc_html_e('Important Security Notice', 'woocodes'); ?>
                    </h3>
                    <p style="margin: 0; color: #92400e; font-size: 14px;">
                        <?php esc_html_e('These codes are unique to your order. Do not share them with others as they can only be used once. If you suspect unauthorized use, contact us immediately.', 'woocodes'); ?>
                    </p>
                </div>

            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #6b7280;">
                    <p><?php esc_html_e('No digital codes are available for this order.', 'woocodes'); ?></p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Footer Section -->
        <div class="footer-section">
            <?php if (!empty($footer_link)): ?>
                <a href="<?php echo esc_url($footer_link); ?>" class="back-button">
                    🔗 <?php echo esc_html($back_to_store_text); ?>
                </a>
            <?php endif; ?>

            <?php if (!empty($support_message)): ?>
                <p class="support-info">
                    <?php echo esc_html($support_message); ?>
                    <?php if (!empty($support_link)): ?>
                        <a href="<?php echo esc_url($support_link); ?>" class="support-link">
                            <?php echo esc_html($support_link_text); ?>
                        </a>
                    <?php endif; ?>
                </p>
            <?php endif; ?>

            <div class="footer-note">
                <p>
                    <?php 
                    printf(
                        /* translators: %s: site name */
                        esc_html__('This email was sent from %s', 'woocodes'),
                        '<strong>' . esc_html(get_bloginfo('name')) . '</strong>'
                    );
                    ?>
                </p>
                <p>
                    <?php 
                    printf(
                        /* translators: %s: current date */
                        esc_html__('Email sent on %s', 'woocodes'),
                        date_i18n(get_option('date_format') . ' ' . get_option('time_format'))
                    );
                    ?>
                </p>
                
                <?php if ($order): ?>
                    <p>
                        <a href="<?php echo esc_url($order->get_view_order_url()); ?>" style="color: #6b7280; font-size: 12px;">
                            <?php esc_html_e('View Order Details', 'woocodes'); ?>
                        </a>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Tracking Pixel (if needed) -->
    <?php if (apply_filters('woocodes_email_tracking_enabled', false)): ?>
        <img src="<?php echo esc_url(add_query_arg(array(
            'woocodes_email_open' => 1,
            'order_id' => $order ? $order->get_id() : 0,
            'hash' => wp_hash($order ? $order->get_id() . $order->get_order_key() : '')
        ), home_url())); ?>" width="1" height="1" style="display: none;" alt="" />
    <?php endif; ?>
</body>
</html>