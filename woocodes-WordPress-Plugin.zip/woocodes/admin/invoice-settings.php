<?php
/**
 * WooCodes Invoice Settings Page
 *
 * @package WooCodes\Admin
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

// Security check
if (!current_user_can('manage_woocommerce')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'woocodes'));
}

// Get current settings
$logo_id = get_option('woocodes_invoice_logo_id', '');
$logo_url = $logo_id ? wp_get_attachment_url($logo_id) : '';
$footer_link = get_option('woocodes_invoice_footer_link', get_home_url());
$selected_color = get_option('woocodes_invoice_color', '#4f46e5');
$email_title = get_option('woocodes_email_title', __('Thank you for your order!', 'woocodes'));
$back_to_store_text = get_option('woocodes_back_to_store_text', __('Back to store', 'woocodes'));
$codes_description = get_option('woocodes_codes_description', __('Here are the codes for your order:', 'woocodes'));
$support_message = get_option('woocodes_support_message', __('If you need any help, please contact us', 'woocodes'));
$support_link_text = get_option('woocodes_support_link_text', __('here', 'woocodes'));
$support_link = get_option('woocodes_support_link', '');

$text_color = woocodes_get_contrast_color($selected_color);
?>

<div class="wrap woocodes-admin-wrap">
    <h1 class="woocodes-page-title">
        <span class="woocodes-icon">⚙️</span>
        <?php esc_html_e('Invoice Settings', 'woocodes'); ?>
    </h1>

    <div class="woocodes-settings-container">
        <!-- Settings Form -->
        <div class="woocodes-settings-form">
            <form method="post" id="woocodes-invoice-form">
                <?php wp_nonce_field('woocodes_invoice_settings', 'woocodes_invoice_settings_nonce'); ?>
                
                <div class="woocodes-form-section">
                    <h3><?php esc_html_e('Brand Customization', 'woocodes'); ?></h3>
                    
                    <div class="woocodes-form-row">
                        <label class="woocodes-label">
                            <strong><?php esc_html_e('Logo:', 'woocodes'); ?></strong>
                        </label>
                        <div id="woocodes-logo-preview" <?php echo $logo_url ? '' : 'style="display:none;"'; ?>>
                            <img src="<?php echo esc_url($logo_url); ?>" alt="<?php esc_attr_e('Logo Preview', 'woocodes'); ?>" style="max-width: 150px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                            <br><br>
                            <button type="button" id="woocodes-remove-logo" class="button">
                                <?php esc_html_e('Remove Logo', 'woocodes'); ?>
                            </button>
                        </div>
                        <button type="button" id="woocodes-upload-logo" class="button" <?php echo $logo_url ? 'style="display:none;"' : ''; ?>>
                            <span class="dashicons dashicons-upload"></span>
                            <?php esc_html_e('Upload Logo', 'woocodes'); ?>
                        </button>
                        <input type="hidden" name="invoice_logo_id" id="invoice_logo_id" value="<?php echo esc_attr($logo_id); ?>">
                        <p class="description">
                            <?php esc_html_e('Upload a logo that will appear at the top of invoice emails. Recommended size: 300x100px or smaller.', 'woocodes'); ?>
                        </p>
                    </div>

                    <div class="woocodes-form-row">
                        <label for="invoice_color" class="woocodes-label">
                            <strong><?php esc_html_e('Brand Color:', 'woocodes'); ?></strong>
                        </label>
                        <input type="color" name="invoice_color" id="invoice_color" value="<?php echo esc_attr($selected_color); ?>" class="woocodes-color-picker">
                        <p class="description">
                            <?php esc_html_e('Choose the primary color for your invoice emails and thank you page.', 'woocodes'); ?>
                        </p>
                    </div>
                </div>

                <div class="woocodes-form-section">
                    <h3><?php esc_html_e('Email Content', 'woocodes'); ?></h3>
                    
                    <div class="woocodes-form-row">
                        <label for="email_title" class="woocodes-label">
                            <strong><?php esc_html_e('Email Title:', 'woocodes'); ?></strong>
                        </label>
                        <input type="text" name="email_title" id="email_title" value="<?php echo esc_attr($email_title); ?>" class="woocodes-select">
                        <p class="description">
                            <?php esc_html_e('The main title that appears in the email and thank you page.', 'woocodes'); ?>
                        </p>
                    </div>

                    <div class="woocodes-form-row">
                        <label for="codes_description" class="woocodes-label">
                            <strong><?php esc_html_e('Codes Description:', 'woocodes'); ?></strong>
                        </label>
                        <input type="text" name="codes_description" id="codes_description" value="<?php echo esc_attr($codes_description); ?>" class="woocodes-select">
                        <p class="description">
                            <?php esc_html_e('Text that appears before the codes list.', 'woocodes'); ?>
                        </p>
                    </div>
                </div>

                <div class="woocodes-form-section">
                    <h3><?php esc_html_e('Footer Settings', 'woocodes'); ?></h3>
                    
                    <div class="woocodes-form-row">
                        <label for="back_to_store_text" class="woocodes-label">
                            <strong><?php esc_html_e('Back to Store Button Text:', 'woocodes'); ?></strong>
                        </label>
                        <input type="text" name="back_to_store_text" id="back_to_store_text" value="<?php echo esc_attr($back_to_store_text); ?>" class="woocodes-select">
                        <p class="description">
                            <?php esc_html_e('Text for the button that links back to your store.', 'woocodes'); ?>
                        </p>
                    </div>

                    <div class="woocodes-form-row">
                        <label for="invoice_footer_link" class="woocodes-label">
                            <strong><?php esc_html_e('Footer Link URL:', 'woocodes'); ?></strong>
                        </label>
                        <input type="url" name="invoice_footer_link" id="invoice_footer_link" value="<?php echo esc_attr($footer_link); ?>" class="woocodes-select">
                        <p class="description">
                            <?php esc_html_e('URL where the back to store button will redirect (usually your homepage or shop page).', 'woocodes'); ?>
                        </p>
                    </div>
                </div>

                <div class="woocodes-form-section">
                    <h3><?php esc_html_e('Support Information', 'woocodes'); ?></h3>
                    
                    <div class="woocodes-form-row">
                        <label for="support_message" class="woocodes-label">
                            <strong><?php esc_html_e('Support Message:', 'woocodes'); ?></strong>
                        </label>
                        <input type="text" name="support_message" id="support_message" value="<?php echo esc_attr($support_message); ?>" class="woocodes-select">
                        <p class="description">
                            <?php esc_html_e('Message that appears before the support link.', 'woocodes'); ?>
                        </p>
                    </div>

                    <div class="woocodes-form-row">
                        <label for="support_link_text" class="woocodes-label">
                            <strong><?php esc_html_e('Support Link Text:', 'woocodes'); ?></strong>
                        </label>
                        <input type="text" name="support_link_text" id="support_link_text" value="<?php echo esc_attr($support_link_text); ?>" class="woocodes-select">
                        <p class="description">
                            <?php esc_html_e('Text for the support link (e.g., "here", "contact us").', 'woocodes'); ?>
                        </p>
                    </div>

                    <div class="woocodes-form-row">
                        <label for="support_link" class="woocodes-label">
                            <strong><?php esc_html_e('Support Link URL:', 'woocodes'); ?></strong>
                        </label>
                        <input type="url" name="support_link" id="support_link" value="<?php echo esc_attr($support_link); ?>" class="woocodes-select">
                        <p class="description">
                            <?php esc_html_e('URL for your support page or contact form.', 'woocodes'); ?>
                        </p>
                    </div>
                </div>

                <div class="woocodes-form-actions">
                    <button type="submit" class="button button-primary woocodes-btn-primary">
                        <span class="dashicons dashicons-saved"></span>
                        <?php esc_html_e('Save Settings', 'woocodes'); ?>
                    </button>
                    <button type="button" id="woocodes-reset-settings" class="button woocodes-btn-secondary">
                        <span class="dashicons dashicons-undo"></span>
                        <?php esc_html_e('Reset to Defaults', 'woocodes'); ?>
                    </button>
                </div>
            </form>
        </div>

        <!-- Live Preview -->
        <div class="woocodes-preview-container">
            <h2>
                <span class="dashicons dashicons-visibility"></span>
                <?php esc_html_e('Live Preview', 'woocodes'); ?>
            </h2>
            <p class="description">
                <?php esc_html_e('See how your invoice email will look to customers:', 'woocodes'); ?>
            </p>
            
            <div id="woocodes-live-preview">
                <?php
                $preview_codes = array(
                    array('product' => __('Sample Product 1', 'woocodes'), 'codes' => array('CODE123', 'CODE456')),
                    array('product' => __('Sample Product 2', 'woocodes'), 'codes' => array('CODE789'))
                );
                
                echo woocodes_generate_invoice_html($preview_codes, array(
                    'logo_url' => $logo_url,
                    'email_title' => $email_title,
                    'back_to_store_text' => $back_to_store_text,
                    'footer_link' => $footer_link,
                    'codes_description' => $codes_description,
                    'support_message' => $support_message,
                    'support_link_text' => $support_link_text,
                    'support_link' => $support_link,
                    'selected_color' => $selected_color,
                    'text_color' => $text_color,
                ));
                ?>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Live preview updates
    function updatePreview() {
        var data = {
            action: 'woocodes_update_invoice_preview',
            nonce: woocodes_admin.nonce,
            logo_url: $('#woocodes-logo-preview img').attr('src') || '',
            email_title: $('#email_title').val(),
            back_to_store_text: $('#back_to_store_text').val(),
            footer_link: $('#invoice_footer_link').val(),
            codes_description: $('#codes_description').val(),
            support_message: $('#support_message').val(),
            support_link_text: $('#support_link_text').val(),
            support_link: $('#support_link').val(),
            selected_color: $('#invoice_color').val()
        };

        $.post(woocodes_admin.ajax_url, data, function(response) {
            $('#woocodes-live-preview').html(response);
        });
    }

    // Update preview on form changes
    $('#woocodes-invoice-form input, #woocodes-invoice-form select, #woocodes-invoice-form textarea').on('input change', function() {
        setTimeout(updatePreview, 300);
    });

    // Logo upload functionality
    var woocodes_media_frame;

    $('#woocodes-upload-logo').on('click', function(e) {
        e.preventDefault();

        if (woocodes_media_frame) {
            woocodes_media_frame.open();
            return;
        }

        woocodes_media_frame = wp.media.frames.woocodes_media_frame = wp.media({
            title: woocodes_admin.strings.choose_logo,
            button: {
                text: woocodes_admin.strings.use_logo
            },
            library: {
                type: 'image'
            },
            multiple: false
        });

        woocodes_media_frame.on('select', function() {
            var attachment = woocodes_media_frame.state().get('selection').first().toJSON();
            
            $('#invoice_logo_id').val(attachment.id);
            $('#woocodes-logo-preview img').attr('src', attachment.url);
            $('#woocodes-logo-preview').show();
            $('#woocodes-upload-logo').hide();
            
            updatePreview();
        });

        woocodes_media_frame.open();
    });

    // Remove logo
    $('#woocodes-remove-logo').on('click', function(e) {
        e.preventDefault();
        
        $('#invoice_logo_id').val('');
        $('#woocodes-logo-preview').hide();
        $('#woocodes-upload-logo').show();
        
        updatePreview();
    });

    // Reset to defaults
    $('#woocodes-reset-settings').on('click', function(e) {
        e.preventDefault();
        
        if (confirm('<?php echo esc_js(__('Are you sure you want to reset all settings to defaults? This cannot be undone.', 'woocodes')); ?>')) {
            $('#email_title').val('<?php echo esc_js(__('Thank you for your order!', 'woocodes')); ?>');
            $('#back_to_store_text').val('<?php echo esc_js(__('Back to store', 'woocodes')); ?>');
            $('#codes_description').val('<?php echo esc_js(__('Here are the codes for your order:', 'woocodes')); ?>');
            $('#support_message').val('<?php echo esc_js(__('If you need any help, please contact us', 'woocodes')); ?>');
            $('#support_link_text').val('<?php echo esc_js(__('here', 'woocodes')); ?>');
            $('#support_link').val('');
            $('#invoice_footer_link').val('<?php echo esc_js(get_home_url()); ?>');
            $('#invoice_color').val('#4f46e5');
            $('#invoice_logo_id').val('');
            $('#woocodes-logo-preview').hide();
            $('#woocodes-upload-logo').show();
            
            updatePreview();
        }
    });

    // Color picker change
    $('#invoice_color').on('change', function() {
        updatePreview();
    });
});
</script>

<style>
.woocodes-color-picker {
    width: 60px;
    height: 40px;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    cursor: pointer;
    padding: 0;
    background: none;
}

.woocodes-color-picker::-webkit-color-swatch-wrapper {
    padding: 0;
    border: none;
    border-radius: 4px;
}

.woocodes-color-picker::-webkit-color-swatch {
    border: none;
    border-radius: 4px;
}
</style>