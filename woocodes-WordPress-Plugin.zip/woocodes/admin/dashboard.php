<?php
/**
 * WooCodes Admin Dashboard
 *
 * @package WooCodes\Admin
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

// Security check
if (!current_user_can('manage_woocommerce')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'woocodes'));
}

$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'codes';
$selected_product = isset($_POST['product_id']) ? intval($_POST['product_id']) : '';
?>

<div class="wrap woocodes-admin-wrap">
    <h1 class="woocodes-page-title">
        <span class="woocodes-icon">📦</span>
        <?php esc_html_e('WooCodes - Digital Product Codes Management', 'woocodes'); ?>
    </h1>

    <nav class="nav-tab-wrapper woocodes-nav-tabs">
        <a href="<?php echo esc_url(admin_url('admin.php?page=woocodes-dashboard&tab=codes')); ?>" 
           class="nav-tab <?php echo ($active_tab === 'codes') ? 'nav-tab-active' : ''; ?>">
            <span class="dashicons dashicons-editor-code"></span>
            <?php esc_html_e('Codes Management', 'woocodes'); ?>
        </a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=woocodes-dashboard&tab=logs')); ?>" 
           class="nav-tab <?php echo ($active_tab === 'logs') ? 'nav-tab-active' : ''; ?>">
            <span class="dashicons dashicons-list-view"></span>
            <?php esc_html_e('Sent Codes Log', 'woocodes'); ?>
        </a>
    </nav>

    <div class="woocodes-tab-content">
        <?php if ($active_tab === 'logs'): ?>
            <?php woocodes_render_logs_tab(); ?>
        <?php else: ?>
            <?php woocodes_render_codes_tab($selected_product); ?>
        <?php endif; ?>
    </div>
</div>

<?php
/**
 * Render codes management tab
 */
function woocodes_render_codes_tab($selected_product) {
    ?>
    <div class="woocodes-codes-section">
        <div class="woocodes-card">
            <div class="woocodes-card-header">
                <h2><?php esc_html_e('Add Codes to Product', 'woocodes'); ?></h2>
                <p class="description">
                    <?php esc_html_e('Select a product and add digital codes that will be automatically sent to customers after purchase.', 'woocodes'); ?>
                </p>
            </div>

            <form method="post" enctype="multipart/form-data" class="woocodes-form">
                <?php wp_nonce_field('woocodes_save_codes', 'woocodes_save_codes_nonce'); ?>
                
                <div class="woocodes-form-row">
                    <label for="product_id" class="woocodes-label">
                        <strong><?php esc_html_e('Select Product:', 'woocodes'); ?></strong>
                    </label>
                    <select name="product_id" id="product_id" class="woocodes-select" onchange="this.form.submit()">
                        <option value=""><?php esc_html_e('-- Select Product --', 'woocodes'); ?></option>
                        <?php
                        $args = array(
                            'post_type' => 'product',
                            'post_status' => 'publish',
                            'posts_per_page' => -1,
                            'orderby' => 'title',
                            'order' => 'ASC',
                        );
                        $products = get_posts($args);
                        
                        foreach ($products as $product_post) {
                            $product = wc_get_product($product_post->ID);
                            if (!$product) continue;
                            
                            $selected = ($selected_product == $product->get_id()) ? 'selected' : '';
                            $virtual_indicator = $product->is_virtual() ? ' 📱' : '';
                            echo '<option value="' . esc_attr($product->get_id()) . '" ' . $selected . '>' 
                                 . esc_html($product->get_name()) . $virtual_indicator . '</option>';
                        }
                        wp_reset_postdata();
                        ?>
                    </select>
                </div>

                <?php if ($selected_product): ?>
                    <div class="woocodes-form-section">
                        <div class="woocodes-form-row">
                            <label for="codes" class="woocodes-label">
                                <strong><?php esc_html_e('Enter Codes (one code per line):', 'woocodes'); ?></strong>
                            </label>
                            <textarea name="codes" id="codes" rows="10" class="woocodes-textarea" 
                                      placeholder="<?php esc_attr_e('Example:&#10;ABC123-XYZ456&#10;DEF789-UVW012&#10;GHI345-STU678', 'woocodes'); ?>"></textarea>
                        </div>
                        
                        <div class="woocodes-form-actions">
                            <button type="submit" name="save_codes" class="button button-primary woocodes-btn-primary">
                                <span class="dashicons dashicons-saved"></span>
                                <?php esc_html_e('Save Codes', 'woocodes'); ?>
                            </button>
                        </div>
                    </div>

                    <div class="woocodes-divider">
                        <span><?php esc_html_e('OR', 'woocodes'); ?></span>
                    </div>

                    <div class="woocodes-form-section">
                        <h3><?php esc_html_e('Upload CSV File', 'woocodes'); ?></h3>
                        <p class="description">
                            <?php esc_html_e('Upload a CSV file with one code per line. The first column should contain the codes.', 'woocodes'); ?>
                        </p>
                        
                        <div class="woocodes-form-row">
                            <label for="csv_file" class="woocodes-label">
                                <strong><?php esc_html_e('Choose CSV File:', 'woocodes'); ?></strong>
                            </label>
                            <input type="file" name="csv_file" id="csv_file" accept=".csv" class="woocodes-file-input">
                        </div>
                        
                        <div class="woocodes-form-actions">
                            <?php wp_nonce_field('woocodes_upload_csv', 'woocodes_upload_csv_nonce'); ?>
                            <button type="submit" name="upload_csv" class="button woocodes-btn-secondary">
                                <span class="dashicons dashicons-upload"></span>
                                <?php esc_html_e('Upload CSV', 'woocodes'); ?>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
            </form>
        </div>

        <?php if ($selected_product): ?>
            <?php woocodes_render_product_codes($selected_product); ?>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Render product codes list
 */
function woocodes_render_product_codes($product_id) {
    $product = wc_get_product($product_id);
    if (!$product) {
        return;
    }
    
    $existing_codes = woocodes_get_product_codes($product_id);
    ?>
    <div class="woocodes-card">
        <div class="woocodes-card-header">
            <h2>
                <?php 
                printf(
                    /* translators: %s: product name */
                    esc_html__('Current Codes for: %s', 'woocodes'),
                    '<strong>' . esc_html($product->get_name()) . '</strong>'
                ); 
                ?>
            </h2>
            <div class="woocodes-codes-stats">
                <span class="woocodes-count-badge">
                    <?php 
                    printf(
                        /* translators: %d: number of codes */
                        esc_html(_n('%d code available', '%d codes available', count($existing_codes), 'woocodes')),
                        count($existing_codes)
                    ); 
                    ?>
                </span>
            </div>
        </div>

        <?php if (!empty($existing_codes)): ?>
            <div class="woocodes-codes-list">
                <?php foreach ($existing_codes as $index => $code): ?>
                    <div class="woocodes-code-item">
                        <div class="woocodes-code-content">
                            <code class="woocodes-code"><?php echo esc_html($code); ?></code>
                            <span class="woocodes-code-index">#<?php echo ($index + 1); ?></span>
                        </div>
                        
                        <div class="woocodes-code-actions">
                            <button type="button" class="woocodes-copy-btn" onclick="woocodesCopyCode('<?php echo esc_js($code); ?>')" 
                                    title="<?php esc_attr_e('Copy to clipboard', 'woocodes'); ?>">
                                <span class="dashicons dashicons-admin-page"></span>
                            </button>
                            
                            <form method="post" style="display: inline-block;" 
                                  onsubmit="return confirm('<?php esc_attr_e('Are you sure you want to delete this code?', 'woocodes'); ?>');">
                                <?php wp_nonce_field('woocodes_delete_code', 'woocodes_delete_code_nonce'); ?>
                                <input type="hidden" name="product_id" value="<?php echo esc_attr($product_id); ?>">
                                <input type="hidden" name="code_to_delete" value="<?php echo esc_attr($code); ?>">
                                <button type="submit" name="delete_code" class="woocodes-delete-btn" 
                                        title="<?php esc_attr_e('Delete code', 'woocodes'); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="woocodes-bulk-actions">
                <button type="button" class="button" onclick="woocodesCopyAllCodes()" 
                        title="<?php esc_attr_e('Copy all codes to clipboard', 'woocodes'); ?>">
                    <span class="dashicons dashicons-admin-page"></span>
                    <?php esc_html_e('Copy All Codes', 'woocodes'); ?>
                </button>
                
                <button type="button" class="button" onclick="woocodesExportCodes()" 
                        title="<?php esc_attr_e('Export codes as CSV', 'woocodes'); ?>">
                    <span class="dashicons dashicons-download"></span>
                    <?php esc_html_e('Export as CSV', 'woocodes'); ?>
                </button>
            </div>
        <?php else: ?>
            <div class="woocodes-empty-state">
                <div class="woocodes-empty-icon">📦</div>
                <h3><?php esc_html_e('No codes found', 'woocodes'); ?></h3>
                <p><?php esc_html_e('Add some codes using the form above to get started.', 'woocodes'); ?></p>
            </div>
        <?php endif; ?>
    </div>

    <script>
    // Copy single code to clipboard
    function woocodesCopyCode(code) {
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(code).then(function() {
                woocodesShowNotice('<?php echo esc_js(__('Code copied to clipboard!', 'woocodes')); ?>', 'success');
            }).catch(function(err) {
                woocodes_fallbackCopy(code);
            });
        } else {
            woocodes_fallbackCopy(code);
        }
    }
    
    // Fallback copy method
    function woocodes_fallbackCopy(text) {
        var textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            woocodesShowNotice('<?php echo esc_js(__('Code copied to clipboard!', 'woocodes')); ?>', 'success');
        } catch (err) {
            woocodesShowNotice('<?php echo esc_js(__('Failed to copy code', 'woocodes')); ?>', 'error');
        }
        
        document.body.removeChild(textArea);
    }

    // Copy all codes to clipboard
    function woocodesCopyAllCodes() {
        var codes = [];
        document.querySelectorAll('.woocodes-code').forEach(function(element) {
            codes.push(element.textContent);
        });
        
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(codes.join('\n')).then(function() {
                woocodesShowNotice('<?php echo esc_js(__('All codes copied to clipboard!', 'woocodes')); ?>', 'success');
            }).catch(function(err) {
                woocodes_fallbackCopy(codes.join('\n'));
            });
        } else {
            woocodes_fallbackCopy(codes.join('\n'));
        }
    }

    // Export codes as CSV
    function woocodesExportCodes() {
        var codes = [];
        document.querySelectorAll('.woocodes-code').forEach(function(element) {
            codes.push(element.textContent);
        });
        
        var csvContent = codes.join('\n');
        var blob = new Blob([csvContent], { type: 'text/csv' });
        var url = window.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'woocodes-export-<?php echo esc_js(date('Y-m-d')); ?>.csv';
        a.click();
        window.URL.revokeObjectURL(url);
        
        woocodesShowNotice('<?php echo esc_js(__('Codes exported successfully!', 'woocodes')); ?>', 'success');
    }

    // Show notification
    function woocodesShowNotice(message, type) {
        var notice = document.createElement('div');
        notice.className = 'notice notice-' + type + ' is-dismissible woocodes-notice';
        notice.innerHTML = '<p>' + message + '</p>';
        
        var wrap = document.querySelector('.woocodes-admin-wrap');
        if (wrap) {
            wrap.insertBefore(notice, wrap.firstChild);
            
            setTimeout(function() {
                if (notice.parentNode) {
                    notice.remove();
                }
            }, 3000);
        }
    }
    </script>
    <?php
}

/**
 * Render logs tab
 */
function woocodes_render_logs_tab() {
    $logs = woocodes_get_sent_logs(array('limit' => 100));
    ?>
    <div class="woocodes-logs-section">
        <div class="woocodes-card">
            <div class="woocodes-card-header">
                <h2><?php esc_html_e('Sent Codes Log', 'woocodes'); ?></h2>
                <p class="description">
                    <?php esc_html_e('Track all digital codes that have been sent to customers.', 'woocodes'); ?>
                </p>
            </div>

            <?php if (!empty($logs)): ?>
                <div class="woocodes-table-container">
                    <table class="wp-list-table widefat fixed striped woocodes-logs-table">
                        <thead>
                            <tr>
                                <th scope="col"><?php esc_html_e('Order', 'woocodes'); ?></th>
                                <th scope="col"><?php esc_html_e('Product', 'woocodes'); ?></th>
                                <th scope="col"><?php esc_html_e('Code', 'woocodes'); ?></th>
                                <th scope="col"><?php esc_html_e('Customer Email', 'woocodes'); ?></th>
                                <th scope="col"><?php esc_html_e('Date Sent', 'woocodes'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo esc_url(admin_url('post.php?post=' . $log['order_id'] . '&action=edit')); ?>" 
                                           target="_blank">
                                            #<?php echo esc_html($log['order_id']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo esc_html($log['product_name']); ?></td>
                                    <td>
                                        <code class="woocodes-log-code"><?php echo esc_html($log['code']); ?></code>
                                        <button type="button" class="woocodes-small-copy-btn" 
                                                onclick="woocodesCopyCode('<?php echo esc_js($log['code']); ?>')"
                                                title="<?php esc_attr_e('Copy code', 'woocodes'); ?>">
                                            📋
                                        </button>
                                    </td>
                                    <td>
                                        <a href="mailto:<?php echo esc_attr($log['customer_email']); ?>">
                                            <?php echo esc_html($log['customer_email']); ?>
                                        </a>
                                    </td>
                                    <td>
                                        <time datetime="<?php echo esc_attr($log['date_sent']); ?>">
                                            <?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log['date_sent']))); ?>
                                        </time>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="woocodes-empty-state">
                    <div class="woocodes-empty-icon">📝</div>
                    <h3><?php esc_html_e('No codes sent yet', 'woocodes'); ?></h3>
                    <p><?php esc_html_e('Codes will appear here after customers complete their orders.', 'woocodes'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}