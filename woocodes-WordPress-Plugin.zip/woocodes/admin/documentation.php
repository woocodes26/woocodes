<?php
/**
 * WooCodes Documentation Page
 *
 * @package WooCodes\Admin
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

// Security check
if (!current_user_can('manage_woocommerce')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'woocodes'));
}
?>

<div class="wrap woocodes-admin-wrap">
    <h1 class="woocodes-page-title">
        <span class="woocodes-icon">📚</span>
        <?php esc_html_e('WooCodes Documentation', 'woocodes'); ?>
    </h1>

    <div class="woocodes-card">
        <div class="woocodes-card-header">
            <h2><?php esc_html_e('Getting Started', 'woocodes'); ?></h2>
            <p class="description">
                <?php esc_html_e('Learn how to set up and use WooCodes effectively for your digital products.', 'woocodes'); ?>
            </p>
        </div>

        <div class="woocodes-form">
            <div class="woocodes-form-section">
                <h3>🚀 <?php esc_html_e('Quick Setup Guide', 'woocodes'); ?></h3>
                
                <ol style="line-height: 1.8; margin-left: 20px;">
                    <li>
                        <strong><?php esc_html_e('Create or Edit a Product:', 'woocodes'); ?></strong><br>
                        <?php esc_html_e('Go to Products → Add New or edit an existing product. Make sure to set it as a "Virtual" product for digital goods.', 'woocodes'); ?>
                    </li>
                    <li>
                        <strong><?php esc_html_e('Add Digital Codes:', 'woocodes'); ?></strong><br>
                        <?php esc_html_e('Navigate to WooCodes → Codes Management, select your product, and add codes either manually or via CSV upload.', 'woocodes'); ?>
                    </li>
                    <li>
                        <strong><?php esc_html_e('Customize Email Templates:', 'woocodes'); ?></strong><br>
                        <?php esc_html_e('Go to WooCodes → Invoice Settings to customize your brand colors, logo, and email content.', 'woocodes'); ?>
                    </li>
                    <li>
                        <strong><?php esc_html_e('Test Your Setup:', 'woocodes'); ?></strong><br>
                        <?php esc_html_e('Make a test purchase to ensure codes are delivered properly after order completion.', 'woocodes'); ?>
                    </li>
                </ol>
            </div>

            <div class="woocodes-form-section">
                <h3>💡 <?php esc_html_e('How It Works', 'woocodes'); ?></h3>
                
                <div style="background: #f6f7f7; padding: 20px; border-radius: 8px; border-left: 4px solid #4f46e5;">
                    <p style="margin: 0 0 10px 0;">
                        <strong><?php esc_html_e('Automatic Delivery Process:', 'woocodes'); ?></strong>
                    </p>
                    <ul style="margin: 0; line-height: 1.6;">
                        <li><?php esc_html_e('Customer completes purchase → Order status changes to "Completed"', 'woocodes'); ?></li>
                        <li><?php esc_html_e('WooCodes automatically assigns codes from your inventory', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Professional email with codes is sent to customer', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Codes also appear on the order confirmation page', 'woocodes'); ?></li>
                        <li><?php esc_html_e('All transactions are logged for your records', 'woocodes'); ?></li>
                    </ul>
                </div>
            </div>

            <div class="woocodes-form-section">
                <h3>📋 <?php esc_html_e('Managing Your Codes', 'woocodes'); ?></h3>
                
                <h4><?php esc_html_e('Adding Codes Manually:', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Select your product from the dropdown', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Enter one code per line in the text area', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Click "Save Codes" to add them to your inventory', 'woocodes'); ?></li>
                </ul>

                <h4><?php esc_html_e('CSV Upload:', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Prepare a CSV file with codes in the first column', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Select your product and choose the CSV file', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Click "Upload CSV" to import all codes at once', 'woocodes'); ?></li>
                </ul>

                <h4><?php esc_html_e('Code Management Features:', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Copy individual codes to clipboard', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Delete unwanted codes', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Copy all codes at once', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Export codes as CSV for backup', 'woocodes'); ?></li>
                </ul>
            </div>

            <div class="woocodes-form-section">
                <h3>🎨 <?php esc_html_e('Customization Options', 'woocodes'); ?></h3>
                
                <h4><?php esc_html_e('Brand Customization:', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Upload your company logo (appears in emails and thank you page)', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Choose your brand color (automatically calculates contrast for text)', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Customize all text content including titles, descriptions, and support messages', 'woocodes'); ?></li>
                </ul>

                <h4><?php esc_html_e('Email Content:', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Email title: Main heading in the email', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Codes description: Text that appears before the codes list', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Support message: Help text with optional support link', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Footer button: Link back to your store', 'woocodes'); ?></li>
                </ul>
            </div>

            <div class="woocodes-form-section">
                <h3>📊 <?php esc_html_e('Monitoring & Logs', 'woocodes'); ?></h3>
                
                <p><?php esc_html_e('The "Sent Codes Log" tab shows you:', 'woocodes'); ?></p>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Which codes were sent to which customers', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Order numbers and product names', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Exact date and time codes were delivered', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Customer email addresses', 'woocodes'); ?></li>
                </ul>
                
                <p><?php esc_html_e('This helps you track your digital inventory and provides customer support when needed.', 'woocodes'); ?></p>
            </div>

            <div class="woocodes-form-section">
                <h3>⚠️ <?php esc_html_e('Important Notes', 'woocodes'); ?></h3>
                
                <div style="background: #fff3cd; padding: 15px; border-radius: 6px; border-left: 4px solid #ffc107;">
                    <ul style="margin: 0; line-height: 1.6;">
                        <li><?php esc_html_e('Codes are automatically removed from inventory when sent to customers', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Make sure to have enough codes in stock before customers can purchase', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Virtual/digital products are recommended for automatic delivery', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Orders are automatically completed for digital-only purchases', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Codes are delivered when order status changes to "Completed"', 'woocodes'); ?></li>
                    </ul>
                </div>
            </div>

            <div class="woocodes-form-section">
                <h3>🔧 <?php esc_html_e('Troubleshooting', 'woocodes'); ?></h3>
                
                <h4><?php esc_html_e('Codes Not Being Sent?', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Check that the order status is "Completed"', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Verify that codes are available for the purchased products', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Check your email server settings (WordPress mail function)', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Look for error messages in the order notes', 'woocodes'); ?></li>
                </ul>

                <h4><?php esc_html_e('Email Formatting Issues?', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Use the live preview in Invoice Settings to test formatting', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Ensure your logo is properly sized (recommended: 300x100px)', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Test different email clients for compatibility', 'woocodes'); ?></li>
                </ul>

                <h4><?php esc_html_e('CSV Upload Problems?', 'woocodes'); ?></h4>
                <ul style="line-height: 1.6;">
                    <li><?php esc_html_e('Ensure codes are in the first column of your CSV', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Use standard CSV format (comma-separated)', 'woocodes'); ?></li>
                    <li><?php esc_html_e('Check for special characters that might cause parsing issues', 'woocodes'); ?></li>
                </ul>
            </div>

            <div class="woocodes-form-section">
                <h3>🔗 <?php esc_html_e('Useful Links', 'woocodes'); ?></h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=woocodes-dashboard')); ?>" class="button button-primary" style="text-align: center;">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <?php esc_html_e('Codes Management', 'woocodes'); ?>
                    </a>
                    
                    <a href="<?php echo esc_url(admin_url('admin.php?page=woocodes-invoice-settings')); ?>" class="button button-primary" style="text-align: center;">
                        <span class="dashicons dashicons-admin-customizer"></span>
                        <?php esc_html_e('Invoice Settings', 'woocodes'); ?>
                    </a>
                    
                    <a href="<?php echo esc_url(admin_url('edit.php?post_type=product')); ?>" class="button button-secondary" style="text-align: center;">
                        <span class="dashicons dashicons-products"></span>
                        <?php esc_html_e('Manage Products', 'woocodes'); ?>
                    </a>
                    
                    <a href="<?php echo esc_url(admin_url('edit.php?post_type=shop_order')); ?>" class="button button-secondary" style="text-align: center;">
                        <span class="dashicons dashicons-list-view"></span>
                        <?php esc_html_e('View Orders', 'woocodes'); ?>
                    </a>
                </div>
            </div>

            <div class="woocodes-form-section">
                <h3>❓ <?php esc_html_e('Frequently Asked Questions', 'woocodes'); ?></h3>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                    <h4><?php esc_html_e('Q: Can I use WooCodes with variable products?', 'woocodes'); ?></h4>
                    <p><?php esc_html_e('A: Yes, you can add codes to individual product variations. Each variation can have its own set of codes.', 'woocodes'); ?></p>
                    
                    <h4><?php esc_html_e('Q: What happens if I run out of codes?', 'woocodes'); ?></h4>
                    <p><?php esc_html_e('A: The product will show as out of stock if no codes are available. Make sure to replenish your code inventory regularly.', 'woocodes'); ?></p>
                    
                    <h4><?php esc_html_e('Q: Can customers see their codes after purchase?', 'woocodes'); ?></h4>
                    <p><?php esc_html_e('A: Yes, codes appear both in the email and on the order confirmation page. Customers can copy codes easily with built-in copy buttons.', 'woocodes'); ?></p>
                    
                    <h4><?php esc_html_e('Q: How do I backup my codes?', 'woocodes'); ?></h4>
                    <p><?php esc_html_e('A: Use the "Export as CSV" feature in Codes Management to download all codes for a product. Regular backups are recommended.', 'woocodes'); ?></p>
                    
                    <h4><?php esc_html_e('Q: Can I customize the email template further?', 'woocodes'); ?></h4>
                    <p><?php esc_html_e('A: The Invoice Settings page provides comprehensive customization options. For advanced modifications, you can use WordPress hooks and filters.', 'woocodes'); ?></p>
                </div>
            </div>

            <div class="woocodes-form-section">
                <h3>🛠️ <?php esc_html_e('Developer Information', 'woocodes'); ?></h3>
                
                <h4><?php esc_html_e('Available Hooks & Filters:', 'woocodes'); ?></h4>
                <div style="background: #1e1e1e; color: #fff; padding: 15px; border-radius: 6px; font-family: monospace; font-size: 13px; overflow-x: auto;">
                    <p style="color: #7dd3fc; margin: 0 0 10px 0;"><?php esc_html_e('// Action Hooks', 'woocodes'); ?></p>
                    <p style="margin: 5px 0;">do_action('woocodes_codes_sent', $order_id, $codes_data);</p>
                    <p style="margin: 5px 0;">do_action('woocodes_process_order_codes', $order_id);</p>
                    <p style="margin: 5px 0;">do_action('woocodes_installed');</p>
                    <br>
                    <p style="color: #7dd3fc; margin: 0 0 10px 0;"><?php esc_html_e('// Filter Hooks', 'woocodes'); ?></p>
                    <p style="margin: 5px 0;">apply_filters('woocodes_email_headers', $headers);</p>
                    <p style="margin: 5px 0;">apply_filters('woocodes_template_path', 'woocodes/');</p>
                </div>

                <h4><?php esc_html_e('Core Functions:', 'woocodes'); ?></h4>
                <div style="background: #1e1e1e; color: #fff; padding: 15px; border-radius: 6px; font-family: monospace; font-size: 13px; overflow-x: auto;">
                    <p style="margin: 5px 0;">woocodes_get_product_codes($product_id)</p>
                    <p style="margin: 5px 0;">woocodes_save_product_codes($product_id, $codes)</p>
                    <p style="margin: 5px 0;">woocodes_product_has_codes($product_id, $quantity)</p>
                    <p style="margin: 5px 0;">woocodes_log_sent_code($log_data)</p>
                    <p style="margin: 5px 0;">woocodes_generate_invoice_html($codes_data, $settings)</p>
                </div>
            </div>

            <div class="woocodes-form-section">
                <h3>📞 <?php esc_html_e('Support & Resources', 'woocodes'); ?></h3>
                
                <div style="background: #e8f5e8; padding: 20px; border-radius: 8px; border-left: 4px solid #28a745;">
                    <p style="margin: 0 0 15px 0;">
                        <strong><?php esc_html_e('Need Help?', 'woocodes'); ?></strong>
                    </p>
                    <p style="margin: 0 0 10px 0;">
                        <?php esc_html_e('If you encounter any issues or need assistance:', 'woocodes'); ?>
                    </p>
                    <ul style="margin: 0; line-height: 1.6;">
                        <li><?php esc_html_e('Check the troubleshooting section above', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Review your WordPress and WooCommerce error logs', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Test with a small number of codes first', 'woocodes'); ?></li>
                        <li><?php esc_html_e('Contact support with specific error messages', 'woocodes'); ?></li>
                    </ul>
                </div>
            </div>

            <div class="woocodes-form-section">
                <h3>📋 <?php esc_html_e('System Requirements', 'woocodes'); ?></h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 6px;">
                        <h4 style="margin: 0 0 10px 0;"><?php esc_html_e('WordPress', 'woocodes'); ?></h4>
                        <p style="margin: 0; color: #666;">Version 5.6+</p>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 6px;">
                        <h4 style="margin: 0 0 10px 0;"><?php esc_html_e('WooCommerce', 'woocodes'); ?></h4>
                        <p style="margin: 0; color: #666;">Version 5.0+</p>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 6px;">
                        <h4 style="margin: 0 0 10px 0;"><?php esc_html_e('PHP', 'woocodes'); ?></h4>
                        <p style="margin: 0; color: #666;">Version 7.4+</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="woocodes-card">
        <div class="woocodes-card-header">
            <h2><?php esc_html_e('Plugin Information', 'woocodes'); ?></h2>
        </div>
        
        <div class="woocodes-form">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <div>
                    <h4><?php esc_html_e('Version', 'woocodes'); ?></h4>
                    <p><?php echo esc_html(WOOCODES_VERSION); ?></p>
                </div>
                
                <div>
                    <h4><?php esc_html_e('Author', 'woocodes'); ?></h4>
                    <p>Mohammed Chalh</p>
                </div>
                
                <div>
                    <h4><?php esc_html_e('Plugin Status', 'woocodes'); ?></h4>
                    <p style="color: #28a745;">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <?php esc_html_e('Active & Running', 'woocodes'); ?>
                    </p>
                </div>
                
                <div>
                    <h4><?php esc_html_e('WooCommerce Status', 'woocodes'); ?></h4>
                    <p style="color: <?php echo class_exists('WooCommerce') ? '#28a745' : '#dc3545'; ?>;">
                        <span class="dashicons dashicons-<?php echo class_exists('WooCommerce') ? 'yes-alt' : 'no-alt'; ?>"></span>
                        <?php echo class_exists('WooCommerce') ? esc_html__('Compatible', 'woocodes') : esc_html__('Not Detected', 'woocodes'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>