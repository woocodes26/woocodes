/**
 * WooCodes Frontend JavaScript
 * 
 * @package WooCodes
 * @version 1.2.0
 */

(function($) {
    'use strict';

    /**
     * Initialize WooCodes Frontend
     */
    function initWooCodesFrontend() {
        initCopyFunctionality();
        initCodeInteractions();
        initResponsiveBehavior();
        initAccessibilityFeatures();
        initAnimations();
        initPrintFunctionality();
    }

    /**
     * Initialize copy to clipboard functionality
     */
    function initCopyFunctionality() {
        // Global copy function for individual codes
        window.woocodesCopyToClipboard = function(text) {
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function() {
                    showCopyNotification('Code copied to clipboard! 📋');
                }).catch(function(err) {
                    fallbackCopy(text);
                });
            } else {
                fallbackCopy(text);
            }
        };

        // Copy all codes function
        window.woocodesCopyAllCodes = function() {
            var codes = [];
            $('.woocodes-code').each(function() {
                codes.push($(this).text().trim());
            });

            if (codes.length === 0) {
                showCopyNotification('No codes to copy', 'error');
                return;
            }

            var allCodesText = codes.join('\n');
            
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(allCodesText).then(function() {
                    showCopyNotification('All codes copied to clipboard! 📋');
                }).catch(function(err) {
                    fallbackCopy(allCodesText);
                });
            } else {
                fallbackCopy(allCodesText);
            }
        };

        // Fallback copy method for older browsers
        function fallbackCopy(text) {
            var textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.position = "fixed";
            textArea.style.left = "-999999px";
            textArea.style.top = "-999999px";
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();

            try {
                document.execCommand('copy');
                showCopyNotification('Code copied to clipboard! 📋');
            } catch (err) {
                showCopyNotification('Please copy manually: ' + text, 'error');
            }

            document.body.removeChild(textArea);
        }

        // Add copy all button if multiple codes exist
        if ($('.woocodes-code').length > 1) {
            var copyAllBtn = $('<button type="button" class="woocodes-copy-all-btn" onclick="woocodesCopyAllCodes()">📋 Copy All Codes</button>');
            $('.woocodes-codes-container').append(copyAllBtn);
        }
    }

    /**
     * Show copy notification
     */
    function showCopyNotification(message, type) {
        type = type || 'success';
        
        // Remove existing notifications
        $('.woocodes-copy-notification').remove();
        
        var notification = $('<div class="woocodes-copy-notification woocodes-copy-' + type + '">' + message + '</div>');
        $('body').append(notification);

        // Auto-remove after 2 seconds
        setTimeout(function() {
            notification.fadeOut(300, function() {
                notification.remove();
            });
        }, 2000);
    }

    /**
     * Initialize code interactions
     */
    function initCodeInteractions() {
        // Enhanced hover effects
        $('.woocodes-code-item').on('mouseenter', function() {
            $(this).addClass('woocodes-code-hover');
        }).on('mouseleave', function() {
            $(this).removeClass('woocodes-code-hover');
        });

        // Double-click to copy
        $('.woocodes-code').on('dblclick', function() {
            var code = $(this).text().trim();
            woocodesCopyToClipboard(code);
        });

        // Keyboard navigation for copy buttons
        $('.woocodes-copy-btn').on('keydown', function(e) {
            if (e.which === 13 || e.which === 32) { // Enter or Space
                e.preventDefault();
                $(this).click();
            }
        });

        // Touch support for mobile
        $('.woocodes-code-item').on('touchstart', function() {
            $(this).addClass('woocodes-code-touch');
        }).on('touchend', function() {
            var $this = $(this);
            setTimeout(function() {
                $this.removeClass('woocodes-code-touch');
            }, 150);
        });

        // Long press to copy on mobile
        var longPressTimer;
        $('.woocodes-code').on('touchstart', function() {
            var code = $(this).text().trim();
            longPressTimer = setTimeout(function() {
                navigator.vibrate && navigator.vibrate(50); // Haptic feedback
                woocodesCopyToClipboard(code);
            }, 1000);
        }).on('touchend touchcancel', function() {
            clearTimeout(longPressTimer);
        });
    }

    /**
     * Initialize responsive behavior
     */
    function initResponsiveBehavior() {
        function adjustLayout() {
            var isMobile = $(window).width() < 768;
            var isTablet = $(window).width() < 960 && $(window).width() >= 768;

            if (isMobile) {
                $('.woocodes-codes-grid').addClass('woocodes-mobile-grid');
                $('.woocodes-invoice-wrapper').addClass('woocodes-mobile-wrapper');
            } else {
                $('.woocodes-codes-grid').removeClass('woocodes-mobile-grid');
                $('.woocodes-invoice-wrapper').removeClass('woocodes-mobile-wrapper');
            }

            if (isTablet) {
                $('.woocodes-codes-grid').addClass('woocodes-tablet-grid');
            } else {
                $('.woocodes-codes-grid').removeClass('woocodes-tablet-grid');
            }
        }

        adjustLayout();
        $(window).on('resize', debounce(adjustLayout, 250));
    }

    /**
     * Initialize accessibility features
     */
    function initAccessibilityFeatures() {
        // Add ARIA labels
        $('.woocodes-copy-btn').attr({
            'aria-label': 'Copy code to clipboard',
            'role': 'button',
            'tabindex': '0'
        });

        $('.woocodes-code').attr({
            'role': 'text',
            'aria-label': 'Digital product code'
        });

        // Keyboard navigation
        $(document).on('keydown', function(e) {
            // Ctrl/Cmd + C to copy all codes
            if ((e.ctrlKey || e.metaKey) && e.which === 67 && $('.woocodes-code').length > 0) {
                e.preventDefault();
                woocodesCopyAllCodes();
            }

            // Escape to clear focus
            if (e.which === 27) {
                $(document.activeElement).blur();
            }
        });

        // Screen reader support
        $('.woocodes-code-item').each(function(index) {
            var code = $(this).find('.woocodes-code').text().trim();
            $(this).attr('aria-label', 'Code ' + (index + 1) + ': ' + code);
        });

        // High contrast mode detection
        if (window.matchMedia && window.matchMedia('(prefers-contrast: high)').matches) {
            $('body').addClass('woocodes-high-contrast');
        }

        // Reduced motion detection
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            $('body').addClass('woocodes-reduced-motion');
        }
    }

    /**
     * Initialize animations
     */
    function initAnimations() {
        // Stagger animation for code items
        $('.woocodes-code-item').each(function(index) {
            $(this).css({
                'animation-delay': (index * 100) + 'ms',
                'animation-duration': '0.5s',
                'animation-name': 'woocodes-fadeInUp',
                'animation-fill-mode': 'both'
            });
        });

        // Add CSS animations
        $('<style>')
            .prop('type', 'text/css')
            .html(`
                @keyframes woocodes-fadeInUp {
                    from {
                        opacity: 0;
                        transform: translate3d(0, 30px, 0);
                    }
                    to {
                        opacity: 1;
                        transform: translate3d(0, 0, 0);
                    }
                }
                
                @keyframes woocodes-pulse {
                    0%, 100% {
                        transform: scale(1);
                    }
                    50% {
                        transform: scale(1.05);
                    }
                }
                
                .woocodes-code-hover {
                    animation: woocodes-pulse 0.3s ease-in-out;
                }
                
                .woocodes-code-touch {
                    background-color: rgba(79, 70, 229, 0.1) !important;
                }
                
                .woocodes-copy-all-btn {
                    background: #4f46e5;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 8px;
                    font-weight: 600;
                    cursor: pointer;
                    margin-top: 20px;
                    transition: all 0.3s ease;
                    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                }
                
                .woocodes-copy-all-btn:hover {
                    background: #3730a3;
                    transform: translateY(-2px);
                    box-shadow: 0 8px 15px -3px rgba(0, 0, 0, 0.1);
                }
                
                .woocodes-copy-success {
                    background: #10b981 !important;
                }
                
                .woocodes-copy-error {
                    background: #ef4444 !important;
                }
                
                @media (prefers-reduced-motion: reduce) {
                    .woocodes-code-item {
                        animation: none !important;
                    }
                    
                    .woocodes-code-hover {
                        animation: none !important;
                    }
                    
                    * {
                        transition: none !important;
                    }
                }
            `)
            .appendTo('head');
    }

    /**
     * Initialize print functionality
     */
    function initPrintFunctionality() {
        // Add print button
        if ($('.woocodes-codes-container').length > 0) {
            var printBtn = $('<button type="button" class="woocodes-print-btn" onclick="woocodesPagePrint()">🖨️ Print Codes</button>');
            $('.woocodes-footer-button').append(printBtn);
        }

        // Print function
        window.woocodesPagePrint = function() {
            // Hide non-essential elements for print
            var elementsToHide = $('.woocodes-copy-btn, .woocodes-copy-all-btn, .woocodes-print-btn');
            elementsToHide.addClass('woocodes-print-hidden');

            window.print();

            // Restore hidden elements after print
            setTimeout(function() {
                elementsToHide.removeClass('woocodes-print-hidden');
            }, 1000);
        };

        // Print styles
        $('<style>')
            .prop('type', 'text/css')
            .html(`
                @media print {
                    .woocodes-print-hidden {
                        display: none !important;
                    }
                    
                    .woocodes-thankyou-container {
                        box-shadow: none !important;
                        border: 2px solid #000 !important;
                        margin: 0 !important;
                    }
                    
                    .woocodes-code-item {
                        break-inside: avoid;
                        border: 1px solid #000 !important;
                    }
                    
                    .woocodes-code {
                        font-size: 14px !important;
                        color: #000 !important;
                    }
                }
                
                .woocodes-print-btn {
                    background: #6b7280;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 6px;
                    font-size: 14px;
                    cursor: pointer;
                    margin-left: 10px;
                    transition: background 0.2s ease;
                }
                
                .woocodes-print-btn:hover {
                    background: #4b5563;
                }
            `)
            .appendTo('head');
    }

    /**
     * Initialize form enhancements
     */
    function initFormEnhancements() {
        // Auto-resize textareas
        $('textarea').each(function() {
            var textarea = this;
            
            function autoResize() {
                textarea.style.height = 'auto';
                textarea.style.height = textarea.scrollHeight + 'px';
            }
            
            $(textarea).on('input', autoResize);
            autoResize(); // Initial resize
        });

        // Form validation
        $('form').on('submit', function(e) {
            var $form = $(this);
            var isValid = true;

            // Validate required fields
            $form.find('[required]').each(function() {
                if (!$(this).val().trim()) {
                    isValid = false;
                    $(this).addClass('woocodes-field-error');
                    showCopyNotification('Please fill in all required fields', 'error');
                } else {
                    $(this).removeClass('woocodes-field-error');
                }
            });

            if (!isValid) {
                e.preventDefault();
                return false;
            }
        });
    }

    /**
     * Initialize product page enhancements
     */
    function initProductPageEnhancements() {
        // Stock level indicator
        $('.woocodes-availability-notice').each(function() {
            var $notice = $(this);
            var stockText = $notice.find('.woocodes-text').text();
            var stockCount = parseInt(stockText.match(/\d+/));

            if (stockCount <= 5) {
                $notice.addClass('woocodes-low-stock');
            } else if (stockCount <= 20) {
                $notice.addClass('woocodes-medium-stock');
            } else {
                $notice.addClass('woocodes-high-stock');
            }
        });

        // Auto-refresh stock info every 30 seconds
        setInterval(function() {
            if ($('.woocodes-availability-notice').length > 0) {
                refreshStockInfo();
            }
        }, 30000);
    }

    /**
     * Refresh stock information
     */
    function refreshStockInfo() {
        var productId = $('input[name="product_id"], input[name="add-to-cart"]').val();
        
        if (!productId) return;

        $.ajax({
            url: woocodes_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'woocodes_get_stock_info',
                product_id: productId,
                nonce: woocodes_frontend.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('.woocodes-availability-notice').replaceWith(response.data);
                }
            }
        });
    }

    /**
     * Initialize security features
     */
    function initSecurityFeatures() {
        // Disable right-click on codes (basic protection)
        $('.woocodes-code').on('contextmenu', function(e) {
            if (woocodes_frontend.disable_right_click) {
                e.preventDefault();
                showCopyNotification('Use the copy button to copy codes', 'info');
                return false;
            }
        });

        // Disable text selection on codes (optional)
        if (woocodes_frontend.disable_text_selection) {
            $('.woocodes-code').css({
                '-webkit-user-select': 'none',
                '-moz-user-select': 'none',
                '-ms-user-select': 'none',
                'user-select': 'none'
            });
        }

        // Prevent copying via keyboard shortcuts (optional)
        if (woocodes_frontend.prevent_keyboard_copy) {
            $(document).on('keydown', function(e) {
                if ((e.ctrlKey || e.metaKey) && (e.which === 67 || e.which === 65)) { // Ctrl+C or Ctrl+A
                    var selection = window.getSelection().toString();
                    if (selection && $('.woocodes-code:contains("' + selection + '")').length > 0) {
                        e.preventDefault();
                        showCopyNotification('Please use the copy buttons provided', 'info');
                    }
                }
            });
        }
    }

    /**
     * Initialize tracking features
     */
    function initTracking() {
        // Track code copy events
        window.woocodesCopyToClipboard = (function(originalFunction) {
            return function(text) {
                // Track copy event
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'code_copied', {
                        'event_category': 'WooCodes',
                        'event_label': 'Digital Code',
                        'value': 1
                    });
                }

                // Send to backend for analytics
                $.post(woocodes_frontend.ajax_url, {
                    action: 'woocodes_track_copy',
                    nonce: woocodes_frontend.nonce,
                    code_hash: btoa(text).substring(0, 10) // Send hash for privacy
                });

                return originalFunction.call(this, text);
            };
        })(window.woocodesCopyToClipboard);

        // Track page views
        if (typeof gtag !== 'undefined' && $('.woocodes-thankyou-container').length > 0) {
            gtag('event', 'codes_delivered', {
                'event_category': 'WooCodes',
                'event_label': 'Thank You Page',
                'value': $('.woocodes-code').length
            });
        }
    }

    /**
     * Initialize error handling
     */
    function initErrorHandling() {
        window.onerror = function(msg, url, lineNo, columnNo, error) {
            // Only handle WooCodes related errors
            if (msg.toLowerCase().includes('woocodes')) {
                console.error('WooCodes Frontend Error:', {
                    message: msg,
                    source: url,
                    line: lineNo,
                    column: columnNo,
                    error: error
                });

                // Show user-friendly error message
                showCopyNotification('Something went wrong. Please refresh the page.', 'error');
            }
            return false;
        };

        // Handle AJAX errors
        $(document).ajaxError(function(event, xhr, settings) {
            if (settings.url && settings.url.includes('woocodes')) {
                showCopyNotification('Connection error. Please try again.', 'error');
            }
        });
    }

    /**
     * Initialize performance optimization
     */
    function initPerformanceOptimization() {
        // Lazy load images
        $('img[data-src]').each(function() {
            var $img = $(this);
            var src = $img.attr('data-src');
            
            if (isElementInViewport($img[0])) {
                $img.attr('src', src).removeAttr('data-src');
            }
        });

        // Throttle scroll events
        $(window).on('scroll', throttle(function() {
            $('img[data-src]').each(function() {
                var $img = $(this);
                if (isElementInViewport($img[0])) {
                    var src = $img.attr('data-src');
                    $img.attr('src', src).removeAttr('data-src');
                }
            });
        }, 100));
    }

    /**
     * Check if element is in viewport
     */
    function isElementInViewport(element) {
        var rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    /**
     * Debounce function
     */
    function debounce(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    /**
     * Throttle function
     */
    function throttle(func, limit) {
        var inThrottle;
        return function() {
            var args = arguments;
            var context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(function() {
                    inThrottle = false;
                }, limit);
            }
        };
    }

    /**
     * Initialize social sharing
     */
    function initSocialSharing() {
        if ($('.woocodes-codes-container').length === 0) return;

        var shareBtn = $('<button type="button" class="woocodes-share-btn">📤 Share</button>');
        $('.woocodes-footer-button').append(shareBtn);

        shareBtn.on('click', function() {
            if (navigator.share) {
                navigator.share({
                    title: 'My Digital Codes',
                    text: 'I received my digital product codes!',
                    url: window.location.href
                }).catch(function(error) {
                    console.log('Error sharing:', error);
                });
            } else {
                // Fallback: copy URL to clipboard
                woocodesCopyToClipboard(window.location.href);
                showCopyNotification('Page URL copied to clipboard!', 'success');
            }
        });
    }

    /**
     * Initialize code validation display
     */
    function initCodeValidation() {
        $('.woocodes-code').each(function() {
            var $code = $(this);
            var codeText = $code.text().trim();
            
            // Add validation status indicator
            var isValid = validateCodeFormat(codeText);
            var indicator = $('<span class="woocodes-code-indicator"></span>');
            
            if (isValid) {
                indicator.addClass('woocodes-code-valid').text('✓');
            } else {
                indicator.addClass('woocodes-code-warning').text('⚠');
            }
            
            $code.parent().append(indicator);
        });
    }

    /**
     * Validate code format
     */
    function validateCodeFormat(code) {
        // Basic validation - alphanumeric and common separators
        return /^[A-Za-z0-9\-_]+$/.test(code) && code.length >= 4 && code.length <= 50;
    }

    /**
     * Initialize QR code generation (optional feature)
     */
    function initQRCodes() {
        if (typeof QRCode === 'undefined' || !woocodes_frontend.enable_qr_codes) {
            return;
        }

        $('.woocodes-code-item').each(function() {
            var $item = $(this);
            var code = $item.find('.woocodes-code').text().trim();
            var qrContainer = $('<div class="woocodes-qr-container"></div>');
            var qrToggle = $('<button type="button" class="woocodes-qr-toggle">📱 QR</button>');
            
            $item.append(qrToggle);
            $item.append(qrContainer);
            
            qrToggle.on('click', function() {
                if (qrContainer.is(':visible')) {
                    qrContainer.hide();
                } else {
                    if (qrContainer.is(':empty')) {
                        var qr = new QRCode(qrContainer[0], {
                            text: code,
                            width: 128,
                            height: 128,
                            colorDark: '#000000',
                            colorLight: '#ffffff',
                            correctLevel: QRCode.CorrectLevel.M
                        });
                    }
                    qrContainer.show();
                }
            });
        });
    }

    /**
     * Initialize dark mode support
     */
    function initDarkModeSupport() {
        // Detect system dark mode preference
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            $('body').addClass('woocodes-dark-mode');
        }

        // Listen for changes
        if (window.matchMedia) {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
                if (e.matches) {
                    $('body').addClass('woocodes-dark-mode');
                } else {
                    $('body').removeClass('woocodes-dark-mode');
                }
            });
        }

        // Add dark mode toggle if enabled
        if (woocodes_frontend.enable_dark_toggle) {
            var darkToggle = $('<button type="button" class="woocodes-dark-toggle">🌙</button>');
            $('.woocodes-invoice-wrapper').prepend(darkToggle);

            darkToggle.on('click', function() {
                $('body').toggleClass('woocodes-dark-mode-manual');
                var isDark = $('body').hasClass('woocodes-dark-mode-manual');
                $(this).text(isDark ? '☀️' : '🌙');
                
                // Store preference
                localStorage.setItem('woocodes_dark_mode', isDark ? 'true' : 'false');
            });

            // Restore preference
            var savedMode = localStorage.getItem('woocodes_dark_mode');
            if (savedMode === 'true') {
                $('body').addClass('woocodes-dark-mode-manual');
                darkToggle.text('☀️');
            }
        }
    }

    /**
     * Initialize code expiration warnings
     */
    function initExpirationWarnings() {
        $('.woocodes-code-item').each(function() {
            var $item = $(this);
            var expirationDate = $item.data('expiration');
            
            if (!expirationDate) return;
            
            var now = new Date();
            var expiry = new Date(expirationDate);
            var daysUntilExpiry = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
            
            if (daysUntilExpiry <= 7 && daysUntilExpiry > 0) {
                var warning = $('<div class="woocodes-expiration-warning">⏰ Expires in ' + daysUntilExpiry + ' days</div>');
                $item.append(warning);
            } else if (daysUntilExpiry <= 0) {
                var expired = $('<div class="woocodes-expiration-expired">❌ Code expired</div>');
                $item.append(expired).addClass('woocodes-code-expired');
            }
        });
    }

    /**
     * Initialize code usage tracking
     */
    function initUsageTracking() {
        $('.woocodes-code-item').each(function() {
            var $item = $(this);
            var usageCount = $item.data('usage-count') || 0;
            var maxUsage = $item.data('max-usage') || 1;
            
            if (maxUsage > 1) {
                var usageInfo = $('<div class="woocodes-usage-info">Used ' + usageCount + '/' + maxUsage + ' times</div>');
                $item.append(usageInfo);
                
                if (usageCount >= maxUsage) {
                    $item.addClass('woocodes-code-used-up');
                }
            }
        });
    }

    /**
     * Initialize advanced animations
     */
    function initAdvancedAnimations() {
        // Intersection Observer for scroll animations
        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('woocodes-animate-in');
                    }
                });
            }, {
                threshold: 0.1
            });

            $('.woocodes-code-item, .woocodes-product-section').each(function() {
                observer.observe(this);
            });
        }

        // Particle effect on copy (optional)
        if (woocodes_frontend.enable_copy_effects) {
            window.woocodesCopyToClipboard = (function(originalFunction) {
                return function(text) {
                    createCopyParticles(event.target);
                    return originalFunction.call(this, text);
                };
            })(window.woocodesCopyToClipboard);
        }
    }

    /**
     * Create copy particles effect
     */
    function createCopyParticles(element) {
        var rect = element.getBoundingClientRect();
        var centerX = rect.left + rect.width / 2;
        var centerY = rect.top + rect.height / 2;

        for (var i = 0; i < 6; i++) {
            var particle = $('<div class="woocodes-copy-particle">✨</div>');
            $('body').append(particle);

            var angle = (i * 60) * Math.PI / 180;
            var distance = 50;
            var endX = centerX + Math.cos(angle) * distance;
            var endY = centerY + Math.sin(angle) * distance;

            particle.css({
                position: 'fixed',
                left: centerX + 'px',
                top: centerY + 'px',
                pointerEvents: 'none',
                zIndex: 10000,
                fontSize: '12px',
                transition: 'all 0.6s ease-out'
            });

            setTimeout(function(p, x, y) {
                p.css({
                    left: x + 'px',
                    top: y + 'px',
                    opacity: 0,
                    transform: 'scale(0)'
                });
                
                setTimeout(function() {
                    p.remove();
                }, 600);
            }.bind(null, particle, endX, endY), 50);
        }
    }

    /**
     * Initialize service worker for offline support
     */
    function initServiceWorker() {
        if ('serviceWorker' in navigator && woocodes_frontend.enable_offline) {
            navigator.serviceWorker.register('/wp-content/plugins/woocodes/assets/js/sw.js')
                .then(function(registration) {
                    console.log('WooCodes SW registered:', registration);
                })
                .catch(function(error) {
                    console.log('WooCodes SW registration failed:', error);
                });
        }
    }

    /**
     * Initialize custom events
     */
    function initCustomEvents() {
        // Custom event when code is copied
        $(document).on('woocodes:code_copied', function(e, code) {
            console.log('Code copied:', code);
            
            // Custom animations or actions
            $('.woocodes-code:contains("' + code + '")').closest('.woocodes-code-item')
                .addClass('woocodes-code-copied')
                .delay(1000)
                .queue(function() {
                    $(this).removeClass('woocodes-code-copied').dequeue();
                });
        });

        // Trigger custom event in copy function
        window.woocodesCopyToClipboard = (function(originalFunction) {
            return function(text) {
                $(document).trigger('woocodes:code_copied', [text]);
                return originalFunction.call(this, text);
            };
        })(window.woocodesCopyToClipboard);
    }

    // Document ready
    $(document).ready(function() {
        // Core initialization
        initWooCodesFrontend();
        initFormEnhancements();
        initProductPageEnhancements();
        initPerformanceOptimization();

        // Optional features (check if enabled)
        if (woocodes_frontend.enable_security_features) {
            initSecurityFeatures();
        }

        if (woocodes_frontend.enable_tracking) {
            initTracking();
        }

        if (woocodes_frontend.enable_social_sharing) {
            initSocialSharing();
        }

        if (woocodes_frontend.enable_code_validation) {
            initCodeValidation();
        }

        if (woocodes_frontend.enable_qr_codes) {
            initQRCodes();
        }

        if (woocodes_frontend.enable_dark_mode) {
            initDarkModeSupport();
        }

        if (woocodes_frontend.enable_expiration_warnings) {
            initExpirationWarnings();
        }

        if (woocodes_frontend.enable_usage_tracking) {
            initUsageTracking();
        }

        if (woocodes_frontend.enable_advanced_animations) {
            initAdvancedAnimations();
        }

        if (woocodes_frontend.enable_service_worker) {
            initServiceWorker();
        }

        // Always initialize these
        initErrorHandling();
        initCustomEvents();

        // Add dynamic CSS
        $('<style>')
            .prop('type', 'text/css')
            .html(`
                .woocodes-field-error {
                    border-color: #ef4444 !important;
                    box-shadow: 0 0 0 1px #ef4444 !important;
                }
                
                .woocodes-code-indicator {
                    margin-left: 8px;
                    font-size: 12px;
                    padding: 2px 4px;
                    border-radius: 3px;
                }
                
                .woocodes-code-valid {
                    background: #10b981;
                    color: white;
                }
                
                .woocodes-code-warning {
                    background: #f59e0b;
                    color: white;
                }
                
                .woocodes-qr-container {
                    text-align: center;
                    padding: 10px;
                    display: none;
                }
                
                .woocodes-qr-toggle {
                    background: #6b7280;
                    color: white;
                    border: none;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                    cursor: pointer;
                }
                
                .woocodes-dark-toggle {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    background: none;
                    border: none;
                    font-size: 18px;
                    cursor: pointer;
                    border-radius: 50%;
                    width: 36px;
                    height: 36px;
                }
                
                .woocodes-expiration-warning {
                    background: #fbbf24;
                    color: #78350f;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                    margin-top: 8px;
                }
                
                .woocodes-expiration-expired {
                    background: #ef4444;
                    color: white;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                    margin-top: 8px;
                }
                
                .woocodes-code-expired {
                    opacity: 0.6;
                    position: relative;
                }
                
                .woocodes-code-expired::after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 0;
                    right: 0;
                    height: 2px;
                    background: #ef4444;
                    transform: translateY(-50%);
                }
                
                .woocodes-usage-info {
                    font-size: 11px;
                    color: #6b7280;
                    margin-top: 4px;
                }
                
                .woocodes-code-used-up {
                    opacity: 0.5;
                }
                
                .woocodes-animate-in {
                    animation: woocodes-slideInUp 0.6s ease-out;
                }
                
                @keyframes woocodes-slideInUp {
                    from {
                        opacity: 0;
                        transform: translateY(30px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                
                .woocodes-code-copied {
                    background: #10b981 !important;
                    color: white !important;
                    transform: scale(1.02);
                }
                
                .woocodes-copy-particle {
                    user-select: none;
                    pointer-events: none;
                }
                
                @media (prefers-color-scheme: dark), .woocodes-dark-mode, .woocodes-dark-mode-manual {
                    .woocodes-thankyou-container {
                        background: #1f2937 !important;
                        color: #f9fafb !important;
                        border-color: #374151 !important;
                    }
                    
                    .woocodes-codes-container {
                        background: #111827 !important;
                        border-color: #374151 !important;
                    }
                    
                    .woocodes-code-item {
                        background: #1e2936 !important;
                        border-color: #374151 !important;
                        color: #f9fafb !important;
                    }
                    
                    .woocodes-code {
                        color: #f9fafb !important;
                    }
                }
                
                @media (max-width: 768px) {
                    .woocodes-mobile-grid {
                        grid-template-columns: 1fr !important;
                    }
                    
                    .woocodes-mobile-wrapper {
                        padding: 20px 15px !important;
                    }
                }
            `)
            .appendTo('head');

        // Performance tracking
        if (performance && performance.now) {
            var loadTime = performance.now();
            console.log('WooCodes Frontend loaded in ' + Math.round(loadTime) + 'ms');
        }

        // Trigger ready event
        $(document).trigger('woocodes:ready');
    });

})(jQuery);