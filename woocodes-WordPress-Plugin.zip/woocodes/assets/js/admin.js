/**
 * WooCodes Admin JavaScript
 *
 * @package WooCodes\Assets
 * @version 1.2.0
 */

jQuery(document).ready(function($) {
    'use strict';

    // Initialize admin functionality
    WooCodesAdmin.init();
});

/**
 * WooCodes Admin Object
 */
var WooCodesAdmin = {
    
    /**
     * Initialize
     */
    init: function() {
        this.bindEvents();
        this.initTooltips();
    },

    /**
     * Bind events
     */
    bindEvents: function() {
        // Form submission confirmations
        $(document).on('submit', 'form[onsubmit*="confirm"]', function(e) {
            var form = $(this);
            var confirmMessage = form.attr('onsubmit').match(/confirm\('([^']+)'\)/);
            if (confirmMessage && confirmMessage[1]) {
                if (!confirm(confirmMessage[1])) {
                    e.preventDefault();
                    return false;
                }
            }
        });

        // Auto-hide notices
        setTimeout(function() {
            $('.woocodes-notice').fadeOut();
        }, 5000);

        // Smooth scroll for anchor links
        $(document).on('click', 'a[href*="#"]', function(e) {
            var href = $(this).attr('href');
            var target = $(href.substring(href.indexOf('#')));
            if (target.length) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: target.offset().top - 100
                }, 500);
            }
        });
    },

    /**
     * Initialize tooltips
     */
    initTooltips: function() {
        // Add basic tooltip functionality
        $(document).on('mouseenter', '[title]', function() {
            var $this = $(this);
            var title = $this.attr('title');
            if (title) {
                $this.data('original-title', title);
                $this.attr('title', '');
                
                var tooltip = $('<div class="woocodes-tooltip">' + title + '</div>');
                $('body').append(tooltip);
                
                var pos = $this.offset();
                tooltip.css({
                    position: 'absolute',
                    top: pos.top - tooltip.outerHeight() - 5,
                    left: pos.left + ($this.outerWidth() / 2) - (tooltip.outerWidth() / 2),
                    background: '#1d2327',
                    color: '#fff',
                    padding: '6px 10px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    whiteSpace: 'nowrap',
                    zIndex: 999999,
                    opacity: 0
                }).animate({opacity: 1}, 200);
            }
        }).on('mouseleave', '[title], [data-original-title]', function() {
            var $this = $(this);
            var originalTitle = $this.data('original-title');
            if (originalTitle) {
                $this.attr('title', originalTitle);
                $this.removeData('original-title');
            }
            $('.woocodes-tooltip').remove();
        });
    },

    /**
     * Show notice
     */
    showNotice: function(message, type) {
        type = type || 'info';
        var notice = $('<div class="notice notice-' + type + ' is-dismissible woocodes-notice"><p>' + message + '</p></div>');
        $('.woocodes-admin-wrap').prepend(notice);
        
        // Auto hide after 5 seconds
        setTimeout(function() {
            notice.fadeOut(function() {
                notice.remove();
            });
        }, 5000);
        
        // Scroll to top to show notice
        $('html, body').animate({scrollTop: 0}, 300);
    },

    /**
     * Confirm dialog
     */
    confirm: function(message, callback) {
        if (confirm(message)) {
            if (typeof callback === 'function') {
                callback();
            }
            return true;
        }
        return false;
    },

    /**
     * Copy to clipboard
     */
    copyToClipboard: function(text, successMessage, errorMessage) {
        successMessage = successMessage || 'Copied to clipboard!';
        errorMessage = errorMessage || 'Failed to copy';

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(function() {
                WooCodesAdmin.showNotice(successMessage, 'success');
            }).catch(function(err) {
                WooCodesAdmin.fallbackCopy(text, successMessage, errorMessage);
            });
        } else {
            WooCodesAdmin.fallbackCopy(text, successMessage, errorMessage);
        }
    },

    /**
     * Fallback copy method
     */
    fallbackCopy: function(text, successMessage, errorMessage) {
        var textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            WooCodesAdmin.showNotice(successMessage, 'success');
        } catch (err) {
            WooCodesAdmin.showNotice(errorMessage, 'error');
        }
        
        document.body.removeChild(textArea);
    },

    /**
     * Export data as CSV
     */
    exportCSV: function(data, filename) {
        filename = filename || 'woocodes-export-' + new Date().toISOString().slice(0, 10) + '.csv';
        
        var csvContent = '';
        if (Array.isArray(data)) {
            csvContent = data.join('\n');
        } else {
            csvContent = data.toString();
        }
        
        var blob = new Blob([csvContent], { type: 'text/csv' });
        var url = window.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        WooCodesAdmin.showNotice('Export completed successfully!', 'success');
    },

    /**
     * Validate form
     */
    validateForm: function(form) {
        var valid = true;
        var errors = [];
        
        // Check required fields
        form.find('[required]').each(function() {
            var field = $(this);
            var value = field.val().trim();
            
            if (!value) {
                field.addClass('error');
                errors.push(field.closest('.woocodes-form-row').find('label').text().replace(':', '') + ' is required');
                valid = false;
            } else {
                field.removeClass('error');
            }
        });
        
        // Check email fields
        form.find('input[type="email"]').each(function() {
            var field = $(this);
            var value = field.val().trim();
            
            if (value && !WooCodesAdmin.isValidEmail(value)) {
                field.addClass('error');
                errors.push('Please enter a valid email address');
                valid = false;
            }
        });
        
        // Check URL fields
        form.find('input[type="url"]').each(function() {
            var field = $(this);
            var value = field.val().trim();
            
            if (value && !WooCodesAdmin.isValidURL(value)) {
                field.addClass('error');
                errors.push('Please enter a valid URL');
                valid = false;
            }
        });
        
        if (!valid) {
            WooCodesAdmin.showNotice('Please fix the following errors: ' + errors.join(', '), 'error');
        }
        
        return valid;
    },

    /**
     * Validate email
     */
    isValidEmail: function(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    /**
     * Validate URL
     */
    isValidURL: function(url) {
        try {
            new URL(url);
            return true;
        } catch (e) {
            return false;
        }
    },

    /**
     * Format number
     */
    formatNumber: function(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    },

    /**
     * Debounce function
     */
    debounce: function(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }
};

// Global functions for inline event handlers
function woocodesCopyCode(code) {
    WooCodesAdmin.copyToClipboard(code, 'Code copied to clipboard!', 'Failed to copy code');
}

function woocodesCopyAllCodes() {
    var codes = [];
    jQuery('.woocodes-code').each(function() {
        codes.push(jQuery(this).text());
    });
    
    if (codes.length > 0) {
        WooCodesAdmin.copyToClipboard(codes.join('\n'), 'All codes copied to clipboard!', 'Failed to copy codes');
    } else {
        WooCodesAdmin.showNotice('No codes found to copy', 'error');
    }
}

function woocodesExportCodes() {
    var codes = [];
    jQuery('.woocodes-code').each(function() {
        codes.push(jQuery(this).text());
    });
    
    if (codes.length > 0) {
        WooCodesAdmin.exportCSV(codes, 'woocodes-export-' + new Date().toISOString().slice(0, 10) + '.csv');
    } else {
        WooCodesAdmin.showNotice('No codes found to export', 'error');
    }
}

function woocodesShowNotice(message, type) {
    WooCodesAdmin.showNotice(message, type);
}