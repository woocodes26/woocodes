<?php
/**
 * WooCodes Email Handler
 *
 * @package WooCodes\Classes
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

/**
 * WooCodes_Emails Class
 */
class WooCodes_Emails {

    /**
     * Constructor
     */
    public function __construct() {
        add_action('woocommerce_order_status_completed', array($this, 'woocodes_handle_order_completion'));
        add_action('template_redirect', array($this, 'woocodes_auto_complete_digital_orders'));
        add_filter('woocodes_email_headers', array($this, 'woocodes_set_email_headers'));
    }

    /**
     * Auto-complete digital orders on thank you page
     */
    public function woocodes_auto_complete_digital_orders() {
        if (!is_wc_endpoint_url('order-received')) {
            return;
        }

        $order_id = get_query_var('order-received');
        if (!$order_id) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order || $order->has_status('completed')) {
            return;
        }

        // Check if order contains only digital products
        $is_digital_only = $this->woocodes_is_digital_only_order($order);
        
        if ($is_digital_only) {
            $order->update_status('completed', __('Order auto-completed for digital products.', 'woocodes'));
        }
    }

    /**
     * Handle order completion
     *
     * @param int $order_id Order ID
     */
    public function woocodes_handle_order_completion($order_id) {
        if (!$order_id) {
            return;
        }

        // Prevent duplicate processing
        if (woocodes_is_order_processed($order_id)) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $codes_data = $this->woocodes_process_order_codes($order);
        
        if (!empty($codes_data)) {
            // Mark order as processed
            woocodes_mark_order_processed($order_id, $codes_data);
            
            // Send email with codes
            $this->woocodes_send_codes_email($order, $codes_data);

            // Trigger action for extensibility
            do_action('woocodes_codes_sent', $order_id, $codes_data);
        }
    }

    /**
     * Process order codes
     *
     * @param WC_Order $order Order object
     * @return array Processed codes data
     */
    private function woocodes_process_order_codes($order) {
        $codes_data = array();
        $insufficient_stock = array();

        foreach ($order->get_items() as $item_id => $item) {
            $product_id = $item->get_product_id();
            $quantity = $item->get_quantity();
            $product = $item->get_product();

            if (!$product) {
                continue;
            }

            // Check if product has codes
            if (!woocodes_product_has_codes($product_id, $quantity)) {
                $insufficient_stock[] = $product->get_name();
                continue;
            }

            // Remove codes from stock
            $codes = woocodes_remove_product_codes($product_id, $quantity);
            
            if (empty($codes)) {
                continue;
            }

            // Log each sent code
            foreach ($codes as $code) {
                woocodes_log_sent_code(array(
                    'order_id' => $order->get_id(),
                    'product_id' => $product_id,
                    'product_name' => $product->get_name(),
                    'code' => $code,
                    'customer_email' => $order->get_billing_email(),
                ));
            }

            $codes_data[] = array(
                'product' => $product->get_name(),
                'codes' => $codes,
            );
        }

        // Log insufficient stock
        if (!empty($insufficient_stock)) {
            $order->add_order_note(
                sprintf(
                    /* translators: %s: product names */
                    __('Insufficient codes for products: %s', 'woocodes'),
                    implode(', ', $insufficient_stock)
                )
            );
        }

        return $codes_data;
    }

    /**
     * Send codes email to customer
     *
     * @param WC_Order $order      Order object
     * @param array    $codes_data Codes data
     */
    private function woocodes_send_codes_email($order, $codes_data) {
        $customer_email = $order->get_billing_email();
        $customer_name = $order->get_billing_first_name();

        if (empty($customer_email) || empty($codes_data)) {
            return;
        }

        $subject = sprintf(
            /* translators: %1$s: site name, %2$s: order number */
            __('[%1$s] Your digital product codes - Order #%2$s', 'woocodes'),
            get_bloginfo('name'),
            $order->get_order_number()
        );

        $message = $this->woocodes_generate_email_content($order, $codes_data, $customer_name);
        
        $headers = apply_filters('woocodes_email_headers', array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>',
        ));

        $sent = wp_mail($customer_email, $subject, $message, $headers);

        if (!$sent) {
            $order->add_order_note(__('Failed to send codes email to customer.', 'woocodes'));
        } else {
            $order->add_order_note(
                sprintf(
                    /* translators: %s: customer email */
                    __('Digital product codes sent to %s', 'woocodes'),
                    $customer_email
                )
            );
        }
    }

    /**
     * Generate email content
     *
     * @param WC_Order $order        Order object
     * @param array    $codes_data   Codes data
     * @param string   $customer_name Customer name
     * @return string Email HTML content
     */
    private function woocodes_generate_email_content($order, $codes_data, $customer_name) {
        $settings = array(
            'logo_url' => woocodes_get_invoice_logo(),
            'email_title' => woocodes_get_email_title(),
            'codes_description' => woocodes_get_codes_description(),
            'back_to_store_text' => woocodes_get_back_to_store_text(),
            'footer_link' => woocodes_get_invoice_footer_link(),
            'support_message' => woocodes_get_support_message(),
            'support_link_text' => woocodes_get_support_link_text(),
            'support_link' => woocodes_get_support_link(),
            'selected_color' => woocodes_get_selected_color(),
        );

        $settings['text_color'] = woocodes_get_contrast_color($settings['selected_color']);

        // Add customer greeting
        if (!empty($customer_name)) {
            $settings['email_title'] = sprintf(
                /* translators: %1$s: customer name, %2$s: original title */
                __('Hello %1$s, %2$s', 'woocodes'),
                esc_html($customer_name),
                $settings['email_title']
            );
        }

        // Add order information
        $order_info = sprintf(
            /* translators: %s: order number */
            __('Order #%s', 'woocodes'),
            $order->get_order_number()
        );

        $email_html = woocodes_generate_invoice_html($codes_data, $settings);

        // Add order info before codes
        $email_html = str_replace(
            $settings['codes_description'],
            $settings['codes_description'] . '<br><small style="color:#64748b;">' . esc_html($order_info) . '</small>',
            $email_html
        );

        return $email_html;
    }

    /**
     * Check if order contains only digital products
     *
     * @param WC_Order $order Order object
     * @return bool True if digital only
     */
    private function woocodes_is_digital_only_order($order) {
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!$product || !$product->is_virtual()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Set email headers
     *
     * @param array $headers Current headers
     * @return array Modified headers
     */
    public function woocodes_set_email_headers($headers) {
        $from_email = get_option('admin_email');
        $from_name = get_bloginfo('name');

        // Ensure we have proper from header
        $has_from = false;
        foreach ($headers as $header) {
            if (strpos(strtolower($header), 'from:') === 0) {
                $has_from = true;
                break;
            }
        }

        if (!$has_from) {
            $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
        }

        return $headers;
    }
}