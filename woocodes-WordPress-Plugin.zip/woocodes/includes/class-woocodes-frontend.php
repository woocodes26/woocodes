<?php
/**
 * WooCodes Frontend Handler
 *
 * @package WooCodes\Classes
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

/**
 * WooCodes_Frontend Class
 */
class WooCodes_Frontend {

    /**
     * Constructor
     */
    public function __construct() {
        add_action('woocommerce_thankyou', array($this, 'woocodes_display_codes_on_thankyou'), 20);
        add_action('wp_enqueue_scripts', array($this, 'woocodes_frontend_styles'));
        add_filter('woocommerce_is_purchasable', array($this, 'woocodes_check_product_stock'), 10, 2);
        add_action('woocommerce_single_product_summary', array($this, 'woocodes_display_codes_availability'), 25);
    }

    /**
     * Enqueue frontend styles
     */
    public function woocodes_frontend_styles() {
        if (is_wc_endpoint_url('order-received') || is_product()) {
            wp_enqueue_style(
                'woocodes-frontend',
                WOOCODES_PLUGIN_URL . 'assets/css/frontend.css',
                array(),
                WOOCODES_VERSION
            );
        }
    }

    /**
     * Display codes on order thank you page
     *
     * @param int $order_id Order ID
     */
    public function woocodes_display_codes_on_thankyou($order_id) {
        if (!$order_id) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Get codes for this order
        $codes_data = woocodes_get_order_codes($order_id);
        
        // If no codes found, try to process the order
        if (empty($codes_data)) {
            // Only auto-process if order is completed
            if ($order->has_status('completed')) {
                do_action('woocodes_process_order_codes', $order_id);
                $codes_data = woocodes_get_order_codes($order_id);
            }
        }

        if (empty($codes_data)) {
            return;
        }

        $this->woocodes_render_thankyou_codes($codes_data);
    }

    /**
     * Render codes on thank you page
     *
     * @param array $codes_data Codes data
     */
    private function woocodes_render_thankyou_codes($codes_data) {
        $settings = array(
            'logo_url' => woocodes_get_invoice_logo(),
            'email_title' => woocodes_get_email_title(),
            'codes_description' => woocodes_get_codes_description(),
            'back_to_store_text' => woocodes_get_back_to_store_text(),
            'footer_link' => woocodes_get_invoice_footer_link(),
            'support_message' => woocodes_get_support_message(),
            'support_link_text' => woocodes_get_support_link_text(),
            'support_link' => woocodes_get_support_link(),
            'selected_color' => woocodes_get_selected_color(),
        );

        $settings['text_color'] = woocodes_get_contrast_color($settings['selected_color']);

        ?>
        <div class="woocodes-thankyou-container">
            <div class="woocodes-invoice-wrapper">
                <?php if (!empty($settings['logo_url'])): ?>
                    <div class="woocodes-logo">
                        <img src="<?php echo esc_url($settings['logo_url']); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
                    </div>
                <?php endif; ?>

                <h2 class="woocodes-title" style="color: <?php echo esc_attr($settings['selected_color']); ?>;">
                    <span class="woocodes-icon">🎉</span>
                    <?php echo esc_html($settings['email_title']); ?>
                </h2>

                <p class="woocodes-description">
                    <?php echo esc_html($settings['codes_description']); ?>
                </p>

                <div class="woocodes-codes-container">
                    <?php foreach ($codes_data as $entry): ?>
                        <?php if (!isset($entry['product']) || !isset($entry['codes'])) continue; ?>
                        
                        <div class="woocodes-product-section">
                            <h3 class="woocodes-product-title" style="color: <?php echo esc_attr($settings['selected_color']); ?>;">
                                <?php echo esc_html($entry['product']); ?>
                            </h3>
                            
                            <div class="woocodes-codes-grid">
                                <?php foreach ($entry['codes'] as $code): ?>
                                    <div class="woocodes-code-item">
                                        <code class="woocodes-code"><?php echo esc_html($code); ?></code>
                                        <button class="woocodes-copy-btn" onclick="woocodesCopyToClipboard('<?php echo esc_js($code); ?>')" title="<?php esc_attr_e('Copy to clipboard', 'woocodes'); ?>">
                                            📋
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if (!empty($settings['footer_link'])): ?>
                    <div class="woocodes-footer-button">
                        <a href="<?php echo esc_url($settings['footer_link']); ?>" 
                           class="woocodes-back-button" 
                           style="background-color: <?php echo esc_attr($settings['selected_color']); ?>; color: <?php echo esc_attr($settings['text_color']); ?>;">
                            🔗 <?php echo esc_html($settings['back_to_store_text']); ?>
                        </a>
                    </div>
                <?php endif; ?>

                <div class="woocodes-support">
                    <p>
                        <?php echo esc_html($settings['support_message']); ?>
                        <?php if (!empty($settings['support_link'])): ?>
                            <a href="<?php echo esc_url($settings['support_link']); ?>" 
                               style="color: <?php echo esc_attr($settings['selected_color']); ?>;">
                                <?php echo esc_html($settings['support_link_text']); ?>
                            </a>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

        <script>
        function woocodesCopyToClipboard(text) {
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function() {
                    woocodes_showCopyMessage('<?php echo esc_js(__('Copied to clipboard!', 'woocodes')); ?>');
                }).catch(function(err) {
                    woocodes_fallbackCopy(text);
                });
            } else {
                woocodes_fallbackCopy(text);
            }
        }

        function woocodes_fallbackCopy(text) {
            var textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.position = "fixed";
            textArea.style.left = "-999999px";
            textArea.style.top = "-999999px";
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                woocodes_showCopyMessage('<?php echo esc_js(__('Copied to clipboard!', 'woocodes')); ?>');
            } catch (err) {
                woocodes_showCopyMessage('<?php echo esc_js(__('Failed to copy', 'woocodes')); ?>');
            }
            
            document.body.removeChild(textArea);
        }

        function woocodes_showCopyMessage(message) {
            var notification = document.createElement('div');
            notification.textContent = message;
            notification.style.cssText = 'position:fixed;top:20px;right:20px;background:#4CAF50;color:white;padding:10px 20px;border-radius:4px;z-index:10000;font-size:14px;';
            document.body.appendChild(notification);
            
            setTimeout(function() {
                document.body.removeChild(notification);
            }, 2000);
        }
        </script>
        <?php
    }

    /**
     * Check if product has codes available (stock check)
     *
     * @param bool       $purchasable Current purchasable status
     * @param WC_Product $product     Product object
     * @return bool Modified purchasable status
     */
    public function woocodes_check_product_stock($purchasable, $product) {
        if (!$purchasable || !$product->is_virtual()) {
            return $purchasable;
        }

        // Check if this product uses codes
        $codes = woocodes_get_product_codes($product->get_id());
        if (empty($codes)) {
            return $purchasable;
        }

        // For variable products, we need to check each variation
        if ($product->is_type('variable')) {
            return $purchasable; // Let variations handle their own stock
        }

        // Check if we have codes in stock
        return count($codes) > 0;
    }

    /**
     * Display codes availability on product page
     *
     * @param int $product_id Product ID (optional, gets current product if not provided)
     */
    public function woocodes_display_codes_availability($product_id = null) {
        global $product;

        if (!$product_id) {
            $current_product = $product;
        } else {
            $current_product = wc_get_product($product_id);
        }

        if (!$current_product || !$current_product->is_virtual()) {
            return;
        }

        $codes = woocodes_get_product_codes($current_product->get_id());
        if (empty($codes)) {
            return;
        }

        $codes_count = count($codes);
        $selected_color = woocodes_get_selected_color();

        ?>
        <div class="woocodes-availability-notice">
            <div class="woocodes-stock-info" style="border-left-color: <?php echo esc_attr($selected_color); ?>;">
                <span class="woocodes-icon">📦</span>
                <span class="woocodes-text">
                    <?php
                    printf(
                        /* translators: %d: number of codes available */
                        _n(
                            '%d digital code available',
                            '%d digital codes available',
                            $codes_count,
                            'woocodes'
                        ),
                        $codes_count
                    );
                    ?>
                </span>
                
                <?php if ($codes_count <= 5): ?>
                    <span class="woocodes-low-stock">
                        <?php esc_html_e('- Low stock!', 'woocodes'); ?>
                    </span>
                <?php endif; ?>
            </div>
            
            <div class="woocodes-delivery-info">
                <span class="woocodes-icon">✉️</span>
                <span class="woocodes-text">
                    <?php esc_html_e('Digital codes will be delivered instantly after purchase', 'woocodes'); ?>
                </span>
            </div>
        </div>
        <?php
    }

    /**
     * Add codes info to cart items (optional feature)
     *
     * @param array $cart_item_data Cart item data
     * @param int   $product_id     Product ID
     * @param int   $variation_id   Variation ID
     * @return array Modified cart item data
     */
    public function woocodes_add_cart_item_data($cart_item_data, $product_id, $variation_id) {
        $product = wc_get_product($product_id);
        
        if (!$product || !$product->is_virtual()) {
            return $cart_item_data;
        }

        $codes = woocodes_get_product_codes($product_id);
        if (!empty($codes)) {
            $cart_item_data['woocodes_available'] = count($codes);
        }

        return $cart_item_data;
    }

    /**
     * Display codes info in cart
     *
     * @param array $item_data Item data
     * @param array $cart_item Cart item
     * @return array Modified item data
     */
    public function woocodes_display_cart_item_data($item_data, $cart_item) {
        if (isset($cart_item['woocodes_available'])) {
            $item_data[] = array(
                'key' => __('Digital Codes', 'woocodes'),
                'value' => sprintf(
                    /* translators: %d: number of codes */
                    __('%d available', 'woocodes'),
                    $cart_item['woocodes_available']
                ),
            );
        }

        return $item_data;
    }

    /**
     * Validate cart before checkout
     */
    public function woocodes_validate_cart_codes() {
        $cart = WC()->cart;
        $errors = array();

        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $product_id = $cart_item['product_id'];
            $quantity = $cart_item['quantity'];
            $product = $cart_item['data'];

            if (!$product->is_virtual()) {
                continue;
            }

            if (!woocodes_product_has_codes($product_id, $quantity)) {
                $errors[] = sprintf(
                    /* translators: %s: product name */
                    __('Insufficient digital codes available for %s', 'woocodes'),
                    $product->get_name()
                );
            }
        }

        if (!empty($errors)) {
            foreach ($errors as $error) {
                wc_add_notice($error, 'error');
            }
            return false;
        }

        return true;
    }
}