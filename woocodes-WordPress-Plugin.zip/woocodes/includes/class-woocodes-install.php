<?php
/**
 * Installation related functions and actions
 *
 * @package WooCodes\Classes
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

/**
 * WooCodes Installation Class
 */
class WooCodes_Install {

    /**
     * DB version option name
     *
     * @var string
     */
    private static $db_version_option = 'woocodes_db_version';

    /**
     * Current DB version
     *
     * @var string
     */
    private static $db_version = '1.2.0';

    /**
     * Install WooCodes
     */
    public static function woocodes_install() {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                esc_html__('WooCodes requires WooCommerce to be installed and activated.', 'woocodes'),
                esc_html__('Plugin Activation Error', 'woocodes'),
                array('back_link' => true)
            );
        }

        self::woocodes_create_options();
        self::woocodes_create_database_tables();
        self::woocodes_update_db_version();

        // Trigger action
        do_action('woocodes_installed');
    }

    /**
     * Create default options
     */
    private static function woocodes_create_options() {
        $default_options = array(
            'woocodes_invoice_logo_id' => '',
            'woocodes_invoice_footer_link' => get_home_url(),
            'woocodes_invoice_color' => '#4f46e5',
            'woocodes_email_title' => __('Thank you for your order!', 'woocodes'),
            'woocodes_back_to_store_text' => __('Back to store', 'woocodes'),
            'woocodes_codes_description' => __('Here are the codes for your order:', 'woocodes'),
            'woocodes_support_message' => __('If you need any help, please contact us', 'woocodes'),
            'woocodes_support_link_text' => __('here', 'woocodes'),
            'woocodes_support_link' => '',
            'woocodes_logs' => array(),
            'woocodes_version' => WOOCODES_VERSION,
        );

        foreach ($default_options as $option_name => $option_value) {
            if (false === get_option($option_name)) {
                add_option($option_name, $option_value);
            }
        }
    }

    /**
     * Create database tables if needed
     */
    private static function woocodes_create_database_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Create codes log table
        $table_name = $wpdb->prefix . 'woocodes_logs';

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) NOT NULL,
            product_id bigint(20) NOT NULL,
            product_name varchar(255) NOT NULL,
            code varchar(255) NOT NULL,
            customer_email varchar(100) NOT NULL,
            date_sent datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY product_id (product_id),
            KEY customer_email (customer_email)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Update DB version
     */
    private static function woocodes_update_db_version() {
        update_option(self::$db_version_option, self::$db_version);
    }

    /**
     * Get DB version
     *
     * @return string
     */
    public static function woocodes_get_db_version() {
        return get_option(self::$db_version_option, '1.0.0');
    }

    /**
     * Check if update is needed
     *
     * @return bool
     */
    public static function woocodes_needs_db_update() {
        $current_version = self::woocodes_get_db_version();
        return version_compare($current_version, self::$db_version, '<');
    }

    /**
     * Deactivate plugin
     */
    public static function woocodes_deactivate() {
        // Clear any caches
        wp_cache_flush();
        
        // Trigger action
        do_action('woocodes_deactivated');
    }

    /**
     * Uninstall plugin
     */
    public static function woocodes_uninstall() {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        // Remove options
        $options_to_remove = array(
            'woocodes_invoice_logo_id',
            'woocodes_invoice_footer_link',
            'woocodes_invoice_color',
            'woocodes_email_title',
            'woocodes_back_to_store_text',
            'woocodes_codes_description',
            'woocodes_support_message',
            'woocodes_support_link_text',
            'woocodes_support_link',
            'woocodes_logs',
            'woocodes_version',
            self::$db_version_option,
        );

        foreach ($options_to_remove as $option) {
            delete_option($option);
        }

        // Remove database tables
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}woocodes_logs");

        // Remove post meta
        $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_woocodes_%'");

        // Trigger action
        do_action('woocodes_uninstalled');
    }
}