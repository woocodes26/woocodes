<?php
/**
 * WooCodes Admin
 *
 * @package WooCodes\Admin
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

/**
 * WooCodes_Admin Class
 */
class WooCodes_Admin {

    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'woocodes_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'woocodes_admin_scripts'));
        add_action('wp_ajax_woocodes_update_invoice_preview', array($this, 'woocodes_update_invoice_preview_ajax'));
        add_action('admin_init', array($this, 'woocodes_handle_form_submissions'));
    }

    /**
     * Add admin menu
     */
    public function woocodes_admin_menu() {
        $capability = 'manage_woocommerce';
        
        add_menu_page(
            __('WooCodes', 'woocodes'),
            __('WooCodes', 'woocodes'),
            $capability,
            'woocodes-dashboard',
            array($this, 'woocodes_admin_dashboard_page'),
            'dashicons-email-alt',
            56
        );

        add_submenu_page(
            'woocodes-dashboard',
            __('Codes Management', 'woocodes'),
            __('Codes Management', 'woocodes'),
            $capability,
            'woocodes-dashboard',
            array($this, 'woocodes_admin_dashboard_page')
        );

        add_submenu_page(
            'woocodes-dashboard',
            __('Invoice Settings', 'woocodes'),
            __('Invoice Settings', 'woocodes'),
            $capability,
            'woocodes-invoice-settings',
            array($this, 'woocodes_admin_invoice_page')
        );

        add_submenu_page(
            'woocodes-dashboard',
            __('Documentation', 'woocodes'),
            __('Documentation', 'woocodes'),
            $capability,
            'woocodes-documentation',
            array($this, 'woocodes_admin_documentation_page')
        );
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function woocodes_admin_scripts($hook) {
        // Only load on our admin pages
        if (strpos($hook, 'woocodes') === false) {
            return;
        }

        wp_enqueue_style(
            'woocodes-admin-style',
            WOOCODES_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            WOOCODES_VERSION
        );

        wp_enqueue_script(
            'woocodes-admin-script',
            WOOCODES_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            WOOCODES_VERSION,
            true
        );

        // Enqueue media scripts for logo upload
        wp_enqueue_media();

        // Localize script
        wp_localize_script(
            'woocodes-admin-script',
            'woocodes_admin',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('woocodes_admin_nonce'),
                'strings' => array(
                    'choose_logo' => __('Choose Logo', 'woocodes'),
                    'use_logo' => __('Use this logo', 'woocodes'),
                    'remove_logo' => __('Remove Logo', 'woocodes'),
                ),
            )
        );
    }

    /**
     * Handle form submissions
     */
    public function woocodes_handle_form_submissions() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        // Handle codes form submission
        if (isset($_POST['woocodes_save_codes_nonce']) && wp_verify_nonce($_POST['woocodes_save_codes_nonce'], 'woocodes_save_codes')) {
            $this->woocodes_handle_codes_submission();
        }

        // Handle CSV upload
        if (isset($_POST['woocodes_upload_csv_nonce']) && wp_verify_nonce($_POST['woocodes_upload_csv_nonce'], 'woocodes_upload_csv')) {
            $this->woocodes_handle_csv_upload();
        }

        // Handle code deletion
        if (isset($_POST['woocodes_delete_code_nonce']) && wp_verify_nonce($_POST['woocodes_delete_code_nonce'], 'woocodes_delete_code')) {
            $this->woocodes_handle_code_deletion();
        }

        // Handle invoice settings
        if (isset($_POST['woocodes_invoice_settings_nonce']) && wp_verify_nonce($_POST['woocodes_invoice_settings_nonce'], 'woocodes_invoice_settings')) {
            $this->woocodes_handle_invoice_settings();
        }
    }

    /**
     * Handle codes submission
     */
    private function woocodes_handle_codes_submission() {
        if (!isset($_POST['product_id']) || !isset($_POST['codes'])) {
            return;
        }

        $product_id = intval($_POST['product_id']);
        $codes_text = sanitize_textarea_field($_POST['codes']);
        
        if (empty($product_id) || empty($codes_text)) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>' . esc_html__('Please select a product and enter codes.', 'woocodes') . '</p></div>';
            });
            return;
        }

        $codes = array_filter(array_map('trim', explode("\n", $codes_text)));
        $this->woocodes_save_product_codes($product_id, $codes);

        add_action('admin_notices', function() {
            echo '<div class="notice notice-success"><p>' . esc_html__('Codes saved successfully!', 'woocodes') . '</p></div>';
        });
    }

    /**
     * Handle CSV upload
     */
    private function woocodes_handle_csv_upload() {
        if (!isset($_POST['product_id']) || !isset($_FILES['csv_file'])) {
            return;
        }

        $product_id = intval($_POST['product_id']);
        
        if (empty($product_id)) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>' . esc_html__('Please select a product.', 'woocodes') . '</p></div>';
            });
            return;
        }

        $file = $_FILES['csv_file'];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>' . esc_html__('Error uploading file.', 'woocodes') . '</p></div>';
            });
            return;
        }

        $csv_codes = $this->woocodes_parse_csv_file($file['tmp_name']);
        
        if (empty($csv_codes)) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>' . esc_html__('No valid codes found in CSV file.', 'woocodes') . '</p></div>';
            });
            return;
        }

        $this->woocodes_save_product_codes($product_id, $csv_codes);

        add_action('admin_notices', function() use ($csv_codes) {
            $message = sprintf(
                /* translators: %d: number of codes */
                __('Successfully imported %d codes from CSV file!', 'woocodes'),
                count($csv_codes)
            );
            echo '<div class="notice notice-success"><p>' . esc_html($message) . '</p></div>';
        });
    }

    /**
     * Parse CSV file and extract codes
     *
     * @param string $file_path Path to CSV file
     * @return array Array of codes
     */
    private function woocodes_parse_csv_file($file_path) {
        $codes = array();
        
        if (($handle = fopen($file_path, "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                if (!empty($data[0])) {
                    $code = sanitize_text_field(trim($data[0]));
                    if (!empty($code)) {
                        $codes[] = $code;
                    }
                }
            }
            fclose($handle);
        }
        
        return $codes;
    }

    /**
     * Handle code deletion
     */
    private function woocodes_handle_code_deletion() {
        if (!isset($_POST['product_id']) || !isset($_POST['code_to_delete'])) {
            return;
        }

        $product_id = intval($_POST['product_id']);
        $code_to_delete = sanitize_text_field($_POST['code_to_delete']);

        $existing_codes = get_post_meta($product_id, '_woocodes_codes', true);
        if (!is_array($existing_codes)) {
            $existing_codes = array();
        }

        $updated_codes = array_filter($existing_codes, function($code) use ($code_to_delete) {
            return $code !== $code_to_delete;
        });

        update_post_meta($product_id, '_woocodes_codes', $updated_codes);

        add_action('admin_notices', function() use ($code_to_delete) {
            $message = sprintf(
                /* translators: %s: deleted code */
                __('Code deleted: %s', 'woocodes'),
                '<code>' . esc_html($code_to_delete) . '</code>'
            );
            echo '<div class="notice notice-success"><p>' . wp_kses_post($message) . '</p></div>';
        });
    }

    /**
     * Handle invoice settings
     */
    private function woocodes_handle_invoice_settings() {
        $settings = array(
            'woocodes_invoice_logo_id' => intval($_POST['invoice_logo_id'] ?? 0),
            'woocodes_invoice_footer_link' => esc_url_raw($_POST['invoice_footer_link'] ?? ''),
            'woocodes_invoice_color' => sanitize_hex_color($_POST['invoice_color'] ?? '#4f46e5'),
            'woocodes_email_title' => sanitize_text_field($_POST['email_title'] ?? ''),
            'woocodes_back_to_store_text' => sanitize_text_field($_POST['back_to_store_text'] ?? ''),
            'woocodes_codes_description' => sanitize_text_field($_POST['codes_description'] ?? ''),
            'woocodes_support_message' => sanitize_text_field($_POST['support_message'] ?? ''),
            'woocodes_support_link_text' => sanitize_text_field($_POST['support_link_text'] ?? ''),
            'woocodes_support_link' => esc_url_raw($_POST['support_link'] ?? ''),
        );

        foreach ($settings as $option_name => $option_value) {
            update_option($option_name, $option_value);
        }

        add_action('admin_notices', function() {
            echo '<div class="notice notice-success"><p>' . esc_html__('Invoice settings updated successfully.', 'woocodes') . '</p></div>';
        });
    }

    /**
     * Save product codes
     *
     * @param int   $product_id Product ID
     * @param array $codes      Array of codes
     */
    private function woocodes_save_product_codes($product_id, $codes) {
        $existing_codes = get_post_meta($product_id, '_woocodes_codes', true);
        if (!is_array($existing_codes)) {
            $existing_codes = array();
        }

        $merged_codes = array_merge($existing_codes, $codes);
        $unique_codes = array_unique($merged_codes);

        update_post_meta($product_id, '_woocodes_codes', $unique_codes);
    }

    /**
     * Dashboard page
     */
    public function woocodes_admin_dashboard_page() {
        include WOOCODES_PLUGIN_PATH . 'admin/dashboard.php';
    }

    /**
     * Invoice settings page
     */
    public function woocodes_admin_invoice_page() {
        include WOOCODES_PLUGIN_PATH . 'admin/invoice-settings.php';
    }

    /**
     * Documentation page
     */
    public function woocodes_admin_documentation_page() {
        include WOOCODES_PLUGIN_PATH . 'admin/documentation.php';
    }

    /**
     * AJAX handler for invoice preview update
     */
    public function woocodes_update_invoice_preview_ajax() {
        check_ajax_referer('woocodes_admin_nonce', 'nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_die(-1, 403);
        }

        $logo_url = isset($_POST['logo_url']) ? esc_url($_POST['logo_url']) : '';
        $email_title = isset($_POST['email_title']) ? sanitize_text_field($_POST['email_title']) : __('Thank you for your order!', 'woocodes');
        $back_to_store_text = isset($_POST['back_to_store_text']) ? sanitize_text_field($_POST['back_to_store_text']) : __('Back to store', 'woocodes');
        $footer_link = isset($_POST['footer_link']) ? esc_url($_POST['footer_link']) : '';
        $codes_description = isset($_POST['codes_description']) ? sanitize_text_field($_POST['codes_description']) : __('Here are the codes for your order:', 'woocodes');
        $support_message = isset($_POST['support_message']) ? sanitize_text_field($_POST['support_message']) : __('If you need any help, please contact us', 'woocodes');
        $support_link_text = isset($_POST['support_link_text']) ? sanitize_text_field($_POST['support_link_text']) : __('here', 'woocodes');
        $support_link = isset($_POST['support_link']) ? esc_url($_POST['support_link']) : '';
        $selected_color = isset($_POST['selected_color']) ? sanitize_hex_color($_POST['selected_color']) : '#4f46e5';
        
        $text_color = woocodes_get_contrast_color($selected_color);
        
        $preview_codes = array(
            array('product' => __('Sample Product 1', 'woocodes'), 'codes' => array('CODE123', 'CODE456')),
            array('product' => __('Sample Product 2', 'woocodes'), 'codes' => array('CODE789'))
        );
        
        echo woocodes_generate_invoice_html($preview_codes, array(
            'logo_url' => $logo_url,
            'email_title' => $email_title,
            'back_to_store_text' => $back_to_store_text,
            'footer_link' => $footer_link,
            'codes_description' => $codes_description,
            'support_message' => $support_message,
            'support_link_text' => $support_link_text,
            'support_link' => $support_link,
            'selected_color' => $selected_color,
            'text_color' => $text_color,
        ));
        
        wp_die();
    }
}