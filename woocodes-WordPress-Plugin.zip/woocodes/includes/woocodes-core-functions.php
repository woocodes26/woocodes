<?php
/**
 * WooCodes Core Functions
 *
 * @package WooCodes\Functions
 * @version 1.2.0
 */

if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

/**
 * Get invoice logo URL
 *
 * @return string Logo URL
 */
function woocodes_get_invoice_logo() {
    $logo_id = get_option('woocodes_invoice_logo_id', '');
    return $logo_id ? wp_get_attachment_url($logo_id) : '';
}

/**
 * Get invoice footer link
 *
 * @return string Footer link URL
 */
function woocodes_get_invoice_footer_link() {
    return get_option('woocodes_invoice_footer_link', get_home_url());
}

/**
 * Get selected invoice color
 *
 * @return string Hex color code
 */
function woocodes_get_selected_color() {
    return get_option('woocodes_invoice_color', '#4f46e5');
}

/**
 * Get email title
 *
 * @return string Email title
 */
function woocodes_get_email_title() {
    return get_option('woocodes_email_title', __('Thank you for your order!', 'woocodes'));
}

/**
 * Get back to store button text
 *
 * @return string Button text
 */
function woocodes_get_back_to_store_text() {
    return get_option('woocodes_back_to_store_text', __('Back to store', 'woocodes'));
}

/**
 * Get codes description text
 *
 * @return string Description text
 */
function woocodes_get_codes_description() {
    return get_option('woocodes_codes_description', __('Here are the codes for your order:', 'woocodes'));
}

/**
 * Get support message text
 *
 * @return string Support message
 */
function woocodes_get_support_message() {
    return get_option('woocodes_support_message', __('If you need any help, please contact us', 'woocodes'));
}

/**
 * Get support link text
 *
 * @return string Support link text
 */
function woocodes_get_support_link_text() {
    return get_option('woocodes_support_link_text', __('here', 'woocodes'));
}

/**
 * Get support link URL
 *
 * @return string Support link URL
 */
function woocodes_get_support_link() {
    return get_option('woocodes_support_link', '');
}

/**
 * Get contrast color for given background color
 *
 * @param string $hex_color Hex color code
 * @return string Black or white hex color
 */
function woocodes_get_contrast_color($hex_color) {
    // Remove # if present
    $hex_color = ltrim($hex_color, '#');
    
    // Convert to RGB
    $r = hexdec(substr($hex_color, 0, 2));
    $g = hexdec(substr($hex_color, 2, 2));
    $b = hexdec(substr($hex_color, 4, 2));
    
    // Calculate luminance
    $luminance = (0.299 * $r + 0.587 * $g + 0.114 * $b) / 255;
    
    // Return black or white based on luminance
    return $luminance > 0.5 ? '#111827' : '#ffffff';
}

/**
 * Adjust color brightness
 *
 * @param string $hex_color Hex color code
 * @param int    $percent   Percentage to adjust (-100 to 100)
 * @return string Adjusted hex color
 */
function woocodes_adjust_color_brightness($hex_color, $percent) {
    $hex_color = ltrim($hex_color, '#');
    
    $r = hexdec(substr($hex_color, 0, 2));
    $g = hexdec(substr($hex_color, 2, 2));
    $b = hexdec(substr($hex_color, 4, 2));

    $r = max(0, min(255, $r + ($r * $percent / 100)));
    $g = max(0, min(255, $g + ($g * $percent / 100)));
    $b = max(0, min(255, $b + ($b * $percent / 100)));

    return '#' . str_pad(dechex(round($r)), 2, '0', STR_PAD_LEFT)
               . str_pad(dechex(round($g)), 2, '0', STR_PAD_LEFT)
               . str_pad(dechex(round($b)), 2, '0', STR_PAD_LEFT);
}

/**
 * Get product codes
 *
 * @param int $product_id Product ID
 * @return array Product codes
 */
function woocodes_get_product_codes($product_id) {
    $codes = get_post_meta($product_id, '_woocodes_codes', true);
    return is_array($codes) ? $codes : array();
}

/**
 * Save product codes
 *
 * @param int   $product_id Product ID
 * @param array $codes      Array of codes to save
 * @param bool  $append     Whether to append to existing codes
 * @return bool Success status
 */
function woocodes_save_product_codes($product_id, $codes, $append = true) {
    if (!is_array($codes)) {
        return false;
    }

    // Sanitize codes
    $sanitized_codes = array();
    foreach ($codes as $code) {
        $sanitized_code = sanitize_text_field(trim($code));
        if (!empty($sanitized_code)) {
            $sanitized_codes[] = $sanitized_code;
        }
    }

    if ($append) {
        $existing_codes = woocodes_get_product_codes($product_id);
        $merged_codes = array_merge($existing_codes, $sanitized_codes);
        $unique_codes = array_unique($merged_codes);
        $codes_to_save = $unique_codes;
    } else {
        $codes_to_save = array_unique($sanitized_codes);
    }

    return update_post_meta($product_id, '_woocodes_codes', $codes_to_save);
}

/**
 * Remove codes from product
 *
 * @param int   $product_id Product ID
 * @param array $codes      Codes to remove
 * @param int   $quantity   Number of codes to remove
 * @return array Removed codes
 */
function woocodes_remove_product_codes($product_id, $quantity = 1) {
    $codes = woocodes_get_product_codes($product_id);
    
    if (empty($codes) || count($codes) < $quantity) {
        return array();
    }

    $codes_to_remove = array_splice($codes, 0, $quantity);
    update_post_meta($product_id, '_woocodes_codes', $codes);

    return $codes_to_remove;
}

/**
 * Check if product has enough codes
 *
 * @param int $product_id Product ID
 * @param int $quantity   Required quantity
 * @return bool Whether product has enough codes
 */
function woocodes_product_has_codes($product_id, $quantity = 1) {
    $codes = woocodes_get_product_codes($product_id);
    return count($codes) >= $quantity;
}

/**
 * Log sent code
 *
 * @param array $log_data Log data
 * @return bool Success status
 */
function woocodes_log_sent_code($log_data) {
    global $wpdb;

    $table_name = $wpdb->prefix . 'woocodes_logs';

    $result = $wpdb->insert(
        $table_name,
        array(
            'order_id' => absint($log_data['order_id']),
            'product_id' => absint($log_data['product_id']),
            'product_name' => sanitize_text_field($log_data['product_name']),
            'code' => sanitize_text_field($log_data['code']),
            'customer_email' => sanitize_email($log_data['customer_email']),
            'date_sent' => current_time('mysql'),
        ),
        array('%d', '%d', '%s', '%s', '%s', '%s')
    );

    return $result !== false;
}

/**
 * Get sent codes logs
 *
 * @param array $args Query arguments
 * @return array Logs data
 */
function woocodes_get_sent_logs($args = array()) {
    global $wpdb;

    $defaults = array(
        'limit' => 50,
        'offset' => 0,
        'order_by' => 'date_sent',
        'order' => 'DESC',
    );

    $args = wp_parse_args($args, $defaults);

    $table_name = $wpdb->prefix . 'woocodes_logs';

    $query = $wpdb->prepare(
        "SELECT * FROM {$table_name} ORDER BY {$args['order_by']} {$args['order']} LIMIT %d OFFSET %d",
        $args['limit'],
        $args['offset']
    );

    return $wpdb->get_results($query, ARRAY_A);
}

/**
 * Generate invoice HTML
 *
 * @param array $codes_data Array of product codes data
 * @param array $settings   Invoice settings
 * @return string Generated HTML
 */
function woocodes_generate_invoice_html($codes_data, $settings = array()) {
    $defaults = array(
        'logo_url' => woocodes_get_invoice_logo(),
        'email_title' => woocodes_get_email_title(),
        'codes_description' => woocodes_get_codes_description(),
        'back_to_store_text' => woocodes_get_back_to_store_text(),
        'footer_link' => woocodes_get_invoice_footer_link(),
        'support_message' => woocodes_get_support_message(),
        'support_link_text' => woocodes_get_support_link_text(),
        'support_link' => woocodes_get_support_link(),
        'selected_color' => woocodes_get_selected_color(),
        'text_color' => '',
    );

    $settings = wp_parse_args($settings, $defaults);

    if (empty($settings['text_color'])) {
        $settings['text_color'] = woocodes_get_contrast_color($settings['selected_color']);
    }

    $html = '<div style="max-width:600px;margin:0 auto;background:#f8fafc;padding:30px;border-radius:12px;font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif;text-align:center;color:#333;box-shadow:0 4px 20px rgba(0,0,0,0.08);border:1px solid #e2e8f0;">';

    // Logo
    if (!empty($settings['logo_url'])) {
        $html .= '<img src="' . esc_url($settings['logo_url']) . '" alt="' . esc_attr(get_bloginfo('name')) . '" style="max-width:150px;margin:0 auto 25px;display:block;">';
    }

    // Title
    $html .= '<h2 style="font-weight:800;margin-bottom:15px;color:' . esc_attr($settings['selected_color']) . ';font-size:28px;">' . esc_html($settings['email_title']) . '</h2>';

    // Description
    $html .= '<p style="font-size:18px;margin-bottom:25px;color:#4b5563;line-height:1.5;">' . esc_html($settings['codes_description']) . '</p>';

    // Codes container
    $html .= '<div style="background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.05);padding:25px;margin-bottom:30px;border:1px solid #e2e8f0;text-align:left;">';

    foreach ($codes_data as $entry) {
        if (!isset($entry['product']) || !isset($entry['codes'])) {
            continue;
        }

        $html .= '<div style="margin-bottom:20px;">';
        $html .= '<h3 style="color:' . esc_attr($settings['selected_color']) . ';margin:0 0 10px 0;font-size:18px;">' . esc_html($entry['product']) . '</h3>';

        foreach ($entry['codes'] as $code) {
            $html .= '<div style="background:#f1f5f9;padding:12px;margin:5px 0;border-radius:6px;font-family:monospace;font-weight:600;color:#111827;">' . esc_html($code) . '</div>';
        }

        $html .= '</div>';
    }

    $html .= '</div>';

    // Back to store button
    if (!empty($settings['footer_link'])) {
        $html .= '<a href="' . esc_url($settings['footer_link']) . '" style="display:inline-block;padding:14px 32px;background:' . esc_attr($settings['selected_color']) . ';color:' . esc_attr($settings['text_color']) . ';font-weight:700;border-radius:8px;text-decoration:none;box-shadow:0 4px 6px -1px rgba(0,0,0,0.1),0 2px 4px -1px rgba(0,0,0,0.06);transition:all 0.3s ease;margin-bottom:20px;">' . esc_html($settings['back_to_store_text']) . '</a>';
    }

    // Support message
    $html .= '<p style="margin-top:30px;font-size:14px;color:#64748b;line-height:1.6;">';
    $html .= esc_html($settings['support_message']);
    if (!empty($settings['support_link'])) {
        $html .= ' <a href="' . esc_url($settings['support_link']) . '" style="color:' . esc_attr($settings['selected_color']) . ';text-decoration:underline;font-weight:600;">' . esc_html($settings['support_link_text']) . '</a>';
    }
    $html .= '</p>';

    $html .= '</div>';

    return $html;
}

/**
 * Check if order was already processed for codes
 *
 * @param int $order_id Order ID
 * @return bool Whether order was processed
 */
function woocodes_is_order_processed($order_id) {
    $processed_codes = get_post_meta($order_id, '_woocodes_order_codes', true);
    return !empty($processed_codes);
}

/**
 * Mark order as processed for codes
 *
 * @param int   $order_id Order ID
 * @param array $codes    Processed codes data
 * @return bool Success status
 */
function woocodes_mark_order_processed($order_id, $codes) {
    return update_post_meta($order_id, '_woocodes_order_codes', $codes);
}

/**
 * Get processed codes for order
 *
 * @param int $order_id Order ID
 * @return array Processed codes data
 */
function woocodes_get_order_codes($order_id) {
    $codes = get_post_meta($order_id, '_woocodes_order_codes', true);
    return is_array($codes) ? $codes : array();
}

/**
 * Validate hex color
 *
 * @param string $color Hex color to validate
 * @return string Valid hex color or default
 */
function woocodes_validate_hex_color($color) {
    if (preg_match('/^#[a-f0-9]{6}$/i', $color)) {
        return $color;
    }
    return '#4f46e5'; // Default color
}

/**
 * Get WooCommerce products with codes
 *
 * @return array Products array
 */
function woocodes_get_products_with_codes() {
    $args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_woocodes_codes',
                'compare' => 'EXISTS'
            )
        )
    );

    $products = get_posts($args);
    $products_data = array();

    foreach ($products as $product) {
        $codes = woocodes_get_product_codes($product->ID);
        $products_data[] = array(
            'id' => $product->ID,
            'name' => $product->post_title,
            'codes_count' => count($codes),
        );
    }

    return $products_data;
}